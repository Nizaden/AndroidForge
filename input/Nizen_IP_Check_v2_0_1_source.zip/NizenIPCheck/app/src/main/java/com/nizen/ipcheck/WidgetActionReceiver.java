package com.nizen.ipcheck;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** 处理小组件点击。未导出，只有本 App 的 PendingIntent 能触发。 */
public class WidgetActionReceiver extends BroadcastReceiver {
    static final String ACTION_REFRESH = "com.nizen.ipcheck.action.REFRESH";
    static final String ACTION_TOGGLE = "com.nizen.ipcheck.action.TOGGLE_IP";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_TOGGLE.equals(action)) {
            Store.toggleIpVisible(context);
            WidgetRenderer.renderAll(context, false);
        } else if (ACTION_REFRESH.equals(action)) {
            IpChecker.startRefresh(context, goAsync());
        }
    }
}
