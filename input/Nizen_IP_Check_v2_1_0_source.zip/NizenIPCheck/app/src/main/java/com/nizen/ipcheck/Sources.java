package com.nizen.ipcheck;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Iterator;
import java.util.Locale;

/**
 * 各数据源的解析。字段名均按 2026-11 实际请求到的返回内容编写：
 * - ident.me  /json：ip, aso, asn, type(hosting/isp/business/...), cc
 * - ip-api.com /json：status, query, countryCode, isp, org, mobile, proxy, hosting
 * - ipquery   ?format=json：ip, isp{org,isp}, location{country_code},
 *             risk{is_mobile,is_vpn,is_tor,is_proxy,is_datacenter,risk_score}
 * - proxycheck v3：status, {ip}{network{provider,organisation,type}, location{country_code},
 *             detections{proxy,vpn,compromised,scraper,tor,hosting,anonymous,risk,confidence},
 *             attack_history{...计数}}
 * - ipwho.is：success, ip, country_code, connection{org,isp}
 */
final class Sources {

    enum Id {
        IDENT("ident.me"),
        IPAPI("ip-api.com"),
        IPQUERY("ipquery"),
        PROXYCHECK("proxycheck"),
        IPWHO("ipwho.is");

        final String label;

        Id(String label) {
            this.label = label;
        }
    }

    // 基础类型
    static final int T_NONE = 0;
    static final int T_HOSTING = 1;
    static final int T_RESIDENTIAL = 2;
    static final int T_BUSINESS = 3;
    static final int T_MOBILE = 4;

    /** proxycheck 配额用完 / 被拒绝后的冷却时间 */
    static final long PROXYCHECK_DENIED_COOLDOWN_MS = 60L * 60 * 1000;

    static final class Data {
        Id id;
        String ip;
        String cc;
        String org;
        /** 明确给出的类型；T_NONE 表示没给 */
        int type = T_NONE;
        /** 只知道“不是机房”（也没说是移动网络） */
        boolean notHosting;
        /** 只作参考，不能单独决定结果（ip-api.com） */
        boolean reference;
        // 质量相关标记
        boolean proxy;
        boolean vpn;
        boolean tor;
        boolean compromised;
        boolean scraper;
        boolean anonymous;
        int risk = -1;
        int confidence = -1;
        int attacks;
        String summary = "";

        boolean definitive() {
            return !reference && type != T_NONE;
        }
    }

    private Sources() {
    }

    static String typeName(int t) {
        switch (t) {
            case T_HOSTING:
                return "机房";
            case T_RESIDENTIAL:
                return "住宅";
            case T_BUSINESS:
                return "商业";
            case T_MOBILE:
                return "移动网络";
            default:
                return "未给出";
        }
    }

    static JSONObject json(String body) throws IOException {
        try {
            return new JSONObject(body);
        } catch (JSONException e) {
            throw new IOException("返回的不是 JSON");
        }
    }

    // ---------- ident.me ----------
    static Data parseIdent(JSONObject j) {
        Data d = new Data();
        d.id = Id.IDENT;
        d.ip = text(j, "ip");
        d.cc = text(j, "cc");
        d.org = text(j, "aso");
        String t = lower(text(j, "type"));
        if ("hosting".equals(t)) {
            d.type = T_HOSTING;
        } else if ("isp".equals(t)) {
            d.type = T_RESIDENTIAL; // 运营商宽带
        } else if ("business".equals(t) || "education".equals(t)
                || "government".equals(t) || "banking".equals(t)) {
            d.type = T_BUSINESS;
        } else if ("mobile".equals(t) || "cellular".equals(t)) {
            d.type = T_MOBILE;
        }
        d.summary = "type=" + (t == null ? "无" : t) + " → " + typeName(d.type);
        return d;
    }

    // ---------- ip-api.com（只作参考） ----------
    static Data parseIpApi(JSONObject j) throws IOException {
        if (!"success".equals(j.optString("status", ""))) {
            throw new IOException("失败：" + j.optString("message", "未知原因"));
        }
        Data d = new Data();
        d.id = Id.IPAPI;
        d.reference = true;
        d.ip = text(j, "query");
        d.cc = text(j, "countryCode");
        d.org = first(text(j, "org"), text(j, "isp"));
        boolean hosting = j.optBoolean("hosting", false);
        boolean mobile = j.optBoolean("mobile", false);
        if (hosting) d.type = T_HOSTING;
        else if (mobile) d.type = T_MOBILE;
        else d.notHosting = true;
        d.proxy = j.optBoolean("proxy", false);
        d.summary = "（参考）机房=" + yn(hosting) + "，移动=" + yn(mobile) + "，代理/VPN/Tor=" + yn(d.proxy);
        return d;
    }

    // ---------- ipquery ----------
    static Data parseIpQuery(JSONObject j) throws IOException {
        JSONObject risk = j.optJSONObject("risk");
        if (risk == null) throw new IOException("缺少 risk 字段");
        Data d = new Data();
        d.id = Id.IPQUERY;
        d.ip = text(j, "ip");
        JSONObject isp = j.optJSONObject("isp");
        if (isp != null) d.org = first(text(isp, "org"), text(isp, "isp"));
        JSONObject loc = j.optJSONObject("location");
        if (loc != null) d.cc = text(loc, "country_code");
        boolean dc = risk.optBoolean("is_datacenter", false);
        boolean mobile = risk.optBoolean("is_mobile", false);
        if (dc) d.type = T_HOSTING;
        else if (mobile) d.type = T_MOBILE;
        else d.notHosting = true;
        d.vpn = risk.optBoolean("is_vpn", false);
        d.proxy = risk.optBoolean("is_proxy", false);
        d.tor = risk.optBoolean("is_tor", false);
        d.risk = intOr(risk, "risk_score", -1);
        d.summary = "机房=" + yn(dc) + "，移动=" + yn(mobile) + "，VPN=" + yn(d.vpn)
                + "，代理=" + yn(d.proxy) + "，Tor=" + yn(d.tor) + "，风险分=" + num(d.risk);
        return d;
    }

    // ---------- proxycheck v3 ----------
    static Data parseProxyCheck(JSONObject j, String ip) throws IOException {
        String status = j.optString("status", "");
        if ("denied".equals(status)) {
            throw new Http.RateLimitedException("被拒绝/今日免费次数已用完：" + j.optString("message", ""),
                    PROXYCHECK_DENIED_COOLDOWN_MS);
        }
        if (!"ok".equals(status) && !"warning".equals(status)) {
            throw new IOException("status=" + status + " " + j.optString("message", ""));
        }
        JSONObject rec = j.optJSONObject(ip);
        if (rec == null) {
            Iterator<String> keys = j.keys();
            while (keys.hasNext()) {
                JSONObject o = j.optJSONObject(keys.next());
                if (o != null && o.has("detections")) {
                    rec = o;
                    break;
                }
            }
        }
        if (rec == null) throw new IOException("没有该 IP 的结果");
        JSONObject det = rec.optJSONObject("detections");
        if (det == null) throw new IOException("缺少 detections 字段");
        Data d = new Data();
        d.id = Id.PROXYCHECK;
        d.ip = ip;
        JSONObject net = rec.optJSONObject("network");
        String netType = null;
        if (net != null) {
            d.org = first(text(net, "provider"), text(net, "organisation"));
            netType = text(net, "type");
        }
        JSONObject loc = rec.optJSONObject("location");
        if (loc != null) d.cc = text(loc, "country_code");
        boolean hosting = det.optBoolean("hosting", false);
        if (hosting || "Hosting".equalsIgnoreCase(netType)) d.type = T_HOSTING;
        else if ("Wireless".equalsIgnoreCase(netType)) d.type = T_MOBILE;
        else if ("Residential".equalsIgnoreCase(netType)) d.type = T_RESIDENTIAL;
        else if ("Business".equalsIgnoreCase(netType)) d.type = T_BUSINESS;
        else d.notHosting = true;
        d.proxy = det.optBoolean("proxy", false);
        d.vpn = det.optBoolean("vpn", false);
        d.tor = det.optBoolean("tor", false);
        d.compromised = det.optBoolean("compromised", false);
        d.scraper = det.optBoolean("scraper", false);
        d.anonymous = det.optBoolean("anonymous", false);
        d.risk = intOr(det, "risk", -1);
        d.confidence = intOr(det, "confidence", -1);
        JSONObject attacks = rec.optJSONObject("attack_history");
        if (attacks != null) {
            Iterator<String> it = attacks.keys();
            while (it.hasNext()) {
                d.attacks += Math.max(0, attacks.optInt(it.next(), 0));
            }
        }
        d.summary = "网络类型=" + (netType == null ? "无" : netType) + "，代理=" + yn(d.proxy)
                + "，VPN=" + yn(d.vpn) + "，Tor=" + yn(d.tor) + "，被入侵=" + yn(d.compromised)
                + "，爬虫=" + yn(d.scraper) + "，匿名=" + yn(d.anonymous) + "，机房=" + yn(hosting)
                + "，风险分=" + num(d.risk) + "，可信度=" + num(d.confidence) + "，攻击记录=" + d.attacks;
        return d;
    }

    // ---------- ipwho.is（只补组织名） ----------
    static Data parseIpWho(JSONObject j) throws IOException {
        if (!j.optBoolean("success", false)) {
            throw new IOException("失败：" + j.optString("message", ""));
        }
        Data d = new Data();
        d.id = Id.IPWHO;
        d.ip = text(j, "ip");
        d.cc = text(j, "country_code");
        JSONObject conn = j.optJSONObject("connection");
        if (conn != null) d.org = first(text(conn, "org"), text(conn, "isp"));
        d.summary = "组织=" + (d.org == null ? "无" : d.org);
        return d;
    }

    // ---------- 工具 ----------
    /** 取字符串；JSON null、空串、"null" 都返回 null。 */
    static String text(JSONObject j, String key) {
        if (j == null || !j.has(key) || j.isNull(key)) return null;
        Object v = j.opt(key);
        if (!(v instanceof String)) return v == null ? null : String.valueOf(v);
        String s = ((String) v).trim();
        return s.isEmpty() || "null".equalsIgnoreCase(s) ? null : s;
    }

    private static int intOr(JSONObject j, String key, int def) {
        if (j == null || !j.has(key) || j.isNull(key)) return def;
        Object v = j.opt(key);
        if (v instanceof Number) return ((Number) v).intValue();
        try {
            return Integer.parseInt(String.valueOf(v).trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    static String first(String a, String b) {
        return a != null ? a : b;
    }

    private static String lower(String s) {
        return s == null ? null : s.toLowerCase(Locale.ROOT);
    }

    static String yn(boolean b) {
        return b ? "是" : "否";
    }

    private static String num(int v) {
        return v < 0 ? "无" : String.valueOf(v);
    }
}
