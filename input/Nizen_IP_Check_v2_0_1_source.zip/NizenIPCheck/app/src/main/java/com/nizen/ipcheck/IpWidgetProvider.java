package com.nizen.ipcheck;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;

/**
 * 小组件入口。系统触发的更新只显示缓存，不联网；
 * 唯一例外：第一次添加、还没有任何数据时自动检测一次。
 */
public class IpWidgetProvider extends AppWidgetProvider {

    @Override
    public void onEnabled(Context context) {
        Store.hideIp(context);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        manager.updateAppWidget(appWidgetIds, WidgetRenderer.build(context, false));
        if (!Store.hasData(context)) {
            IpChecker.startRefresh(context, goAsync());
        }
    }
}
