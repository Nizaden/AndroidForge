package com.nizen.ipcheck;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.TrafficStats;
import android.os.SystemClock;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLException;

/**
 * 一次检测。查询流程照搬 FlClash lib/common/ip_quality.dart 的 _Lookup：
 *   第 1 批 ident.me + ip-api.com + ipquery → 第 2 批 iplocate.io → 第 3 批 ipapi.is → 第 4 批 proxycheck
 *   - 每批间隔 1 秒（hedge）；上一批全部结束也会立刻问下一批
 *   - 谁先给出明确类型就用谁，并取消其余所有请求
 *   - “推断”的类型（ip-api / ipquery 没说机房也没说移动 → 住宅）只在所有来源都没明确类型时才用
 * 和 FlClash 不同的地方：
 *   - 出口 IP：FlClash 由 Clash 内核取得；我们没有内核，第 1 批直接问“我的 IP”。
 *     4.ident.me / ip-api.com / api.ipquery.io 都只有 IPv4 解析，所以拿到的一定是 IPv4；
 *     都拿不到才改问 6.ident.me（纯 IPv6 网络）。
 *   - 缓存：同一 IP 1 天；整次失败 5 分钟内不自动重试；429 不重试（我们原来的规则）。
 *   - 机房再用 proxycheck 评干净程度（见 Classifier）。
 */
final class IpChecker {
    static final String IPAPI_FIELDS = "?fields=status,message,query,countryCode,isp,org,as,mobile,proxy,hosting";

    private static final long HEDGE_MS = 1000;
    // FlClash 单个请求超时 8 秒
    private static final int CONNECT_MS = 4000;
    private static final int READ_MS = 4000;
    private static final long LOOKUP_BUDGET_MS = 12000;
    private static final long POST_BUDGET_MS = 6000;
    private static final long DEBOUNCE_MS = 25000;
    private static final int LAST_WAVE = 3;

    private static final Object LOCK = new Object();
    private static boolean running;
    private static long runningSince;

    static final class DetectionResult {
        String ip;
        String countryCode;
        String typeLabel;
        String qualityLabel;
        String organization;
        String details;
        /** 整次失败（5 分钟内不自动重试） */
        boolean failed;
        /** 可以按 IP 缓存 1 天 */
        boolean cacheable;
        boolean fromCache;
        long cacheAgeMs;
    }

    /** 每个具体请求。wave：所属批次；-1 表示机房评级的追加请求。 */
    enum Task {
        IDENT4(Sources.Id.IDENT, 0, "ident.me"),
        IPAPI_SELF(Sources.Id.IPAPI, 0, "ip-api.com"),
        IPQUERY_SELF(Sources.Id.IPQUERY, 0, "ipquery.io"),
        IDENT6(Sources.Id.IDENT, 0, "ident.me(IPv6)"),
        IPAPI_IP(Sources.Id.IPAPI, 0, "ip-api.com"),
        IPQUERY_IP(Sources.Id.IPQUERY, 0, "ipquery.io"),
        IPLOCATE(Sources.Id.IPLOCATE, 1, "iplocate.io"),
        IPAPIIS(Sources.Id.IPAPIIS, 2, "ipapi.is"),
        PROXYCHECK(Sources.Id.PROXYCHECK, 3, "proxycheck.io"),
        PC_CLEAN(Sources.Id.PROXYCHECK, -1, "proxycheck.io(机房评级)"),
        IQ_CLEAN(Sources.Id.IPQUERY, -1, "ipquery.io(机房评级)");

        final Sources.Id id;
        final int wave;
        final String label;

        Task(Sources.Id id, int wave, String label) {
            this.id = id;
            this.wave = wave;
            this.label = label;
        }

        boolean lookup() {
            return wave >= 0;
        }

        String url(String ip) {
            switch (this) {
                case IDENT4:
                    return "https://4.ident.me/json";
                case IDENT6:
                    return "https://6.ident.me/json";
                case IPAPI_SELF:
                    return "http://ip-api.com/json/" + IPAPI_FIELDS; // 唯一的明文地址
                case IPAPI_IP:
                    return "http://ip-api.com/json/" + ip + IPAPI_FIELDS;
                case IPQUERY_SELF:
                    return "https://api.ipquery.io/?format=json";
                case IPQUERY_IP:
                case IQ_CLEAN:
                    return "https://api.ipquery.io/" + ip + "?format=json";
                case IPLOCATE:
                    return "https://iplocate.io/api/lookup/" + ip;
                case IPAPIIS:
                    return "https://api.ipapi.is/?q=" + ip;
                default:
                    return "https://proxycheck.io/v3/" + ip;
            }
        }
    }

    private IpChecker() {
    }

    /**
     * pending 可以为 null（从 App 页面触发时）。
     * force=true：App 里的「重新检测」，跳过缓存和失败等待（限流冷却仍然遵守）。
     */
    static void startRefresh(Context context, final BroadcastReceiver.PendingResult pending, final boolean force) {
        final Context app = context.getApplicationContext();
        if (!force && Store.failureBackoffLeft(app) > 0) {
            WidgetRenderer.renderAll(app, false); // 上次失败不到 5 分钟，不重试
            finishQuietly(pending);
            return;
        }
        synchronized (LOCK) {
            long now = SystemClock.elapsedRealtime();
            if (running && now - runningSince < DEBOUNCE_MS) {
                finishQuietly(pending); // 正在检测，忽略重复点击
                return;
            }
            running = true;
            runningSince = now;
        }
        WidgetRenderer.renderAll(app, true);
        Thread worker = new Thread(() -> {
            try {
                Store.save(app, new Run(app, force).execute());
            } catch (Throwable t) {
                Store.save(app, failure("检测失败", "程序异常：" + t.getClass().getSimpleName()));
            } finally {
                synchronized (LOCK) {
                    running = false;
                }
                try {
                    WidgetRenderer.renderAll(app, false);
                } catch (Throwable ignored) {
                    // 渲染失败不影响 finish
                }
                finishQuietly(pending);
            }
        }, "ip-check");
        worker.start();
    }

    static boolean isRunning() {
        synchronized (LOCK) {
            return running;
        }
    }

    private static void finishQuietly(BroadcastReceiver.PendingResult pending) {
        if (pending != null) {
            try {
                pending.finish();
            } catch (Throwable ignored) {
                // 已结束
            }
        }
    }

    private static final class Answer {
        final Task task;
        final Sources.Parsed parsed;
        final Throwable error;
        final long rateLimitMs;

        Answer(Task task, Sources.Parsed parsed, Throwable error, long rateLimitMs) {
            this.task = task;
            this.parsed = parsed;
            this.error = error;
            this.rateLimitMs = rateLimitMs;
        }
    }

    /** 一次检测的全部状态。只有调用 execute() 的线程会读写这些字段。 */
    private static final class Run {
        final Context app;
        final boolean force;
        final long start = SystemClock.elapsedRealtime();
        final long lookupDeadline = start + LOOKUP_BUDGET_MS;
        long postDeadline;
        final ExecutorService pool = Executors.newFixedThreadPool(Task.values().length);
        final LinkedBlockingQueue<Answer> queue = new LinkedBlockingQueue<>();
        final EnumMap<Task, Http.Call> pending = new EnumMap<>(Task.class);
        final EnumSet<Task> launched = EnumSet.noneOf(Task.class);
        /** 按到达先后 */
        final LinkedHashMap<Sources.Id, Sources.Parsed> parsed = new LinkedHashMap<>();
        final EnumMap<Sources.Id, String> failures = new EnumMap<>(Sources.Id.class);
        final StringBuilder log = new StringBuilder();

        String ip;
        int nextWave = 1;
        long nextWaveAt;
        boolean triedV6;
        boolean lookupDone;
        boolean postStarted;
        Sources.Quality chosen;
        boolean chosenInferred;
        Sources.Quality fallback;
        boolean gradeHosting;
        Sources.Clean pcClean;
        Sources.Clean iqClean;

        Run(Context app, boolean force) {
            this.app = app;
            this.force = force;
        }

        DetectionResult execute() {
            try {
                return doExecute();
            } finally {
                for (Http.Call c : pending.values()) c.cancel();
                pending.clear();
                pool.shutdownNow();
            }
        }

        private DetectionResult doExecute() {
            if (!hasNetwork(app)) return failure("无网络", "没有可用网络");
            final long bytesBefore = uidBytes();
            log(force ? "手动重新检测（跳过缓存）" : "检测开始");
            log("第 1 批：ident.me、ip-api.com、ipquery.io（只走 IPv4）");
            launch(Task.IDENT4);
            launch(Task.IPAPI_SELF);
            launch(Task.IPQUERY_SELF);
            nextWaveAt = start + HEDGE_MS;

            while (true) {
                long now = SystemClock.elapsedRealtime();
                if (!lookupDone) {
                    boolean busy = lookupPending();
                    if (ip != null && nextWave <= LAST_WAVE && (now >= nextWaveAt || !busy)) {
                        launchWave(nextWave++);
                        nextWaveAt = now + HEDGE_MS;
                        continue;
                    }
                    if (!busy) {
                        if (ip == null) {
                            if (!triedV6) {
                                triedV6 = true;
                                log("没拿到 IPv4，按纯 IPv6 网络处理，改问 6.ident.me");
                                if (launch(Task.IDENT6)) {
                                    nextWaveAt = now + HEDGE_MS;
                                    continue;
                                }
                            }
                            return failure("检测失败", "无法获取出口 IP\n各来源：\n" + sourceList() + "过程：\n" + log);
                        }
                        settle();
                        continue;
                    }
                    if (now >= lookupDeadline) {
                        for (Task t : new ArrayList<>(pending.keySet())) {
                            if (t.lookup()) {
                                cancel(t, "超时，放弃");
                                fail(t.id, Sources.Status.TIMEOUT.label);
                            }
                        }
                        nextWave = LAST_WAVE + 1;
                        settle();
                        continue;
                    }
                } else {
                    if (!postStarted) {
                        postStarted = true;
                        postDeadline = now + POST_BUDGET_MS;
                        startPost();
                        continue;
                    }
                    if (pending.isEmpty()) break;
                    if (now >= postDeadline) {
                        for (Task t : new ArrayList<>(pending.keySet())) cancel(t, "超时，放弃");
                        break;
                    }
                }

                long until = lookupDone ? postDeadline : lookupDeadline;
                if (!lookupDone && ip != null && nextWave <= LAST_WAVE) until = Math.min(until, nextWaveAt);
                Answer a;
                try {
                    a = queue.poll(Math.max(1, until - now), TimeUnit.MILLISECONDS);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
                if (a == null) continue;
                if (pending.remove(a.task) == null) continue; // 已取消的请求，结果丢弃
                DetectionResult hit = handle(a);
                if (hit != null) return hit;
            }
            return build(bytesBefore);
        }

        private boolean lookupPending() {
            for (Task t : pending.keySet()) {
                if (t.lookup()) return true;
            }
            return false;
        }

        private void launchWave(int wave) {
            for (Task t : Task.values()) {
                if (t.wave == wave) {
                    log("第 " + (wave + 1) + " 批：" + t.label);
                    launch(t);
                }
            }
        }

        /** FlClash _settle：所有来源都没明确类型时，用第一个“推断”的结果。 */
        private void settle() {
            lookupDone = true;
            if (chosen == null && fallback != null) {
                chosen = fallback;
                chosenInferred = true;
                log("所有来源都没给出明确类型，采用 " + fallback.source.label + " 的推断结果（住宅）");
            }
        }

        /** 判定完成后：机房且没有 Tor/滥用 → 再看干净程度。 */
        private void startPost() {
            if (chosen == null) return;
            Classifier.Verdict base = Classifier.flclashLevel(chosen);
            if (chosen.type != Sources.Type.HOSTING || !Classifier.NORMAL.equals(base.label)) return;
            gradeHosting = true;
            Sources.Parsed pc = parsed.get(Sources.Id.PROXYCHECK);
            if (pc != null && pc.clean != null) {
                pcClean = pc.clean;
                log("机房评级：用已经拿到的 proxycheck 结果");
                return;
            }
            log("机房评级：问 proxycheck 看干净程度");
            if (!launch(Task.PC_CLEAN)) requestIpQuery();
        }

        private void requestIpQuery() {
            Sources.Parsed iq = parsed.get(Sources.Id.IPQUERY);
            if (iq != null && iq.clean != null) {
                iqClean = iq.clean;
                log("机房评级：proxycheck 不可用，用已经拿到的 ipquery 风险分");
                return;
            }
            log("机房评级：proxycheck 不可用，改问 ipquery 的风险分");
            launch(Task.IQ_CLEAN);
        }

        /** 返回 false 表示因冷却跳过，没有发出请求。 */
        private boolean launch(final Task t) {
            if (launched.contains(t)) return false;
            launched.add(t);
            String skip = Store.skipReason(app, t.id, force);
            if (skip != null) {
                log(t.label + "：跳过，" + skip);
                if (t.lookup()) fail(t.id, skip);
                return false;
            }
            final Http.Call call = new Http.Call();
            final String queriedIp = ip;
            final String url = t.url(ip);
            pending.put(t, call);
            pool.execute(() -> {
                try {
                    Http.Response r = Http.get(url, CONNECT_MS, READ_MS, call);
                    Sources.Parsed p = Sources.parse(t.id, r, queriedIp);
                    long rl = 0;
                    if (t.id == Sources.Id.IPAPI && r.xRl != null && "0".equals(r.xRl.trim())) {
                        long s = Http.seconds(r.xTtl);
                        rl = (s > 0 ? s : 60) * 1000L;
                    }
                    queue.add(new Answer(t, p, null, rl));
                } catch (Throwable e) {
                    queue.add(new Answer(t, null, e, 0));
                }
            });
            return true;
        }

        private void cancel(Task t, String why) {
            Http.Call c = pending.remove(t);
            if (c != null) {
                c.cancel();
                log(t.label + "：" + why);
            }
        }

        private void fail(Sources.Id id, String why) {
            if (!parsed.containsKey(id)) failures.put(id, why);
        }

        /** 处理一个结果；命中缓存时返回缓存结果。 */
        private DetectionResult handle(Answer a) {
            Task t = a.task;
            if (a.error != null) {
                Throwable e = a.error;
                String msg;
                if (e instanceof Sources.Failure && ((Sources.Failure) e).coolDownMs > 0) {
                    Sources.Failure f = (Sources.Failure) e;
                    Store.coolDown(app, t.id, f.coolDownMs, true, f.getMessage());
                    msg = f.status.label + "（" + f.getMessage() + "），不重试";
                } else if (e instanceof Sources.Failure) {
                    msg = ((Sources.Failure) e).status.label + "（" + e.getMessage() + "）";
                    if (e.getMessage() != null && e.getMessage().startsWith("HTTP")) {
                        Store.coolDown(app, t.id, Store.FAIL_BACKOFF_MS, false, msg); // 服务器出错：5 分钟内跳过
                    }
                } else {
                    msg = describe(e);
                    Store.coolDown(app, t.id, Store.FAIL_BACKOFF_MS, false, msg);
                }
                log(t.label + "：" + msg);
                if (t.lookup()) fail(t.id, msg);
                else if (t == Task.PC_CLEAN) requestIpQuery();
                return null;
            }
            if (a.rateLimitMs > 0) {
                Store.coolDown(app, t.id, a.rateLimitMs, true, "本分钟次数已用完");
            } else {
                Store.clearCoolDown(app, t.id);
            }

            Sources.Parsed p = a.parsed;
            String rip = normalizeIp(p.ip);
            if (ip == null) {
                if (rip == null || (t != Task.IDENT6 && !isIpv4(rip))) {
                    log(t.label + "：没返回可用的 IPv4，已忽略");
                    fail(t.id, Sources.Status.IP_MISMATCH.label);
                    return null;
                }
                ip = rip;
                log("出口 IP（" + (isIpv4(ip) ? "IPv4" : "IPv6") + "）来自 " + t.label);
                if (!force) {
                    DetectionResult c = Store.cached(app, ip);
                    if (c != null) {
                        for (Task x : new ArrayList<>(pending.keySet())) cancel(x, "已有 1 天内的缓存，取消");
                        long min = c.cacheAgeMs / 60000;
                        c.details = "（缓存结果：" + (min / 60) + " 小时 " + (min % 60)
                                + " 分钟前检测。同一 IP 1 天内不重复查询，要重查请在 App 里点「重新检测」）\n"
                                + c.details;
                        return c;
                    }
                }
                if (t == Task.IDENT6) {
                    // 纯 IPv6：第 1 批的另外两家改用 IP 查询
                    launch(Task.IPAPI_IP);
                    launch(Task.IPQUERY_IP);
                }
            } else if ((t.id == Sources.Id.IDENT && rip == null) || (rip != null && !rip.equals(ip))) {
                log(t.label + "：" + Sources.Status.IP_MISMATCH.label + "（" + p.ip + "），已忽略");
                if (t.lookup()) fail(t.id, Sources.Status.IP_MISMATCH.label);
                return null;
            }

            if (!t.lookup()) { // 机房评级的追加请求
                if (t == Task.PC_CLEAN) {
                    if (p.clean != null) {
                        pcClean = p.clean;
                        log(t.label + "：" + p.clean.summary());
                    } else {
                        log(t.label + "：没有检测数据");
                        requestIpQuery();
                    }
                } else if (p.clean != null) {
                    iqClean = p.clean;
                    log(t.label + "：" + p.clean.summary());
                }
                return null;
            }

            parsed.put(t.id, p);
            failures.remove(t.id);
            log(t.label + "：" + p.summary());
            if (p.quality == null) {
                failures.put(t.id, Sources.Status.NO_TYPE.label);
            } else if (p.inferred) {
                if (fallback == null) fallback = p.quality;
            } else {
                chosen = p.quality;
                lookupDone = true;
                log("→ 先到先用：" + t.label + " 明确给出「" + p.quality.type.label + "」");
                for (Task x : new ArrayList<>(pending.keySet())) {
                    if (x.lookup()) cancel(x, "已有明确类型，取消");
                }
            }
            return null;
        }

        private DetectionResult build(long bytesBefore) {
            DetectionResult r = new DetectionResult();
            r.ip = ip;
            String cc = pickCountry();
            r.countryCode = cc == null ? "--" : cc;

            String typeLine;
            String qualityLine;
            if (chosen == null) {
                r.typeLabel = "类型未知";
                r.qualityLabel = "--";
                r.organization = "--";
                r.failed = true;
                typeLine = "类型未知（没有来源给出类型）";
                qualityLine = "--";
            } else {
                r.typeLabel = chosen.type.label;
                Classifier.Verdict v = Classifier.flclashLevel(chosen);
                if (gradeHosting) {
                    v = Classifier.gradeHosting(pcClean, iqClean, parsed.values());
                }
                r.qualityLabel = v.label;
                qualityLine = v.label + "\n质量依据：" + v.reason;
                String org = chosen.organization != null ? chosen.organization
                        : (chosen.asn != null ? "AS" + chosen.asn : null);
                r.organization = org == null ? "--" : org;
                r.cacheable = true;
                typeLine = r.typeLabel + "（采用来源：" + chosen.source.label
                        + (chosenInferred ? "；推断：没说机房也没说移动，按 FlClash 规则当作住宅" : "") + "）";
            }

            long bytesAfter = uidBytes();
            String traffic = (bytesBefore >= 0 && bytesAfter >= bytesBefore)
                    ? "约 " + ((bytesAfter - bytesBefore + 512) / 1024) + " KB" : "系统不支持统计";
            long cost = SystemClock.elapsedRealtime() - start;
            r.details = "时间：" + now() + "\n"
                    + "IP：" + ip + (isIpv4(ip) ? "（IPv4）" : "（IPv6，没有 IPv4 出口）") + "\n"
                    + "国家：" + r.countryCode + "\n"
                    + "类型：" + typeLine + "\n"
                    + "质量：" + qualityLine + "\n"
                    + "组织：" + r.organization + "\n"
                    + "本次流量：" + traffic + "，耗时 " + cost + "ms\n"
                    + (r.failed ? "没有来源给出类型，5 分钟内不自动重试\n" : "")
                    + "各来源：\n" + sourceList()
                    + "过程：\n" + log;
            return r;
        }

        private String sourceList() {
            StringBuilder sb = new StringBuilder();
            for (Sources.Id id : Sources.Id.values()) {
                Sources.Parsed p = parsed.get(id);
                String f = failures.get(id);
                sb.append("· ").append(id.label).append("：");
                if (p != null && p.quality != null) sb.append(p.summary());
                else if (f != null) sb.append(f);
                else if (p != null) sb.append(p.summary());
                else sb.append("未请求 / 已取消");
                sb.append('\n');
            }
            return sb.toString();
        }

        private String pickCountry() {
            if (chosen != null) {
                Sources.Parsed p = parsed.get(chosen.source);
                String c = p == null ? null : validCountry(p.cc);
                if (c != null) return c;
            }
            for (Sources.Parsed p : parsed.values()) {
                String c = validCountry(p.cc);
                if (c != null) return c;
            }
            return null;
        }

        private void log(String s) {
            log.append("[+").append(SystemClock.elapsedRealtime() - start).append("ms] ")
                    .append(s).append('\n');
        }
    }

    private static String describe(Throwable t) {
        if (t == null) return "未知错误";
        if (t instanceof SocketTimeoutException) return Sources.Status.TIMEOUT.label;
        if (t instanceof UnknownHostException) return "无法解析域名";
        if (t instanceof SSLException) return "加密连接失败";
        if (t instanceof IOException && t.getMessage() != null) return t.getMessage();
        return t.getClass().getSimpleName();
    }

    static boolean isIpv4(String ip) {
        return ip != null && ip.indexOf(':') < 0;
    }

    static String normalizeIp(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        if (s.isEmpty() || s.length() > 64) return null;
        if (s.indexOf(':') >= 0) {
            if (!s.matches("[0-9a-fA-F:.]+")) return null;
        } else {
            String[] parts = s.split("\\.");
            if (parts.length != 4) return null;
            for (String p : parts) {
                if (p.isEmpty() || p.length() > 3 || !p.matches("\\d+") || Integer.parseInt(p) > 255) {
                    return null;
                }
            }
        }
        try {
            return InetAddress.getByName(s).getHostAddress(); // 字面量地址，不会发起 DNS 查询
        } catch (Exception e) {
            return null;
        }
    }

    private static String validCountry(String raw) {
        if (raw == null) return null;
        String c = raw.trim().toUpperCase(Locale.ROOT);
        if (!c.matches("[A-Z]{2}")) return null;
        if ("XX".equals(c) || "T1".equals(c) || "ZZ".equals(c)) return null;
        return c;
    }

    private static boolean hasNetwork(Context app) {
        try {
            ConnectivityManager cm = app.getSystemService(ConnectivityManager.class);
            if (cm == null) return true;
            Network n = cm.getActiveNetwork();
            return n != null;
        } catch (Exception e) {
            return true;
        }
    }

    private static long uidBytes() {
        int uid = android.os.Process.myUid();
        long rx = TrafficStats.getUidRxBytes(uid);
        long tx = TrafficStats.getUidTxBytes(uid);
        if (rx == TrafficStats.UNSUPPORTED || tx == TrafficStats.UNSUPPORTED) return -1;
        return rx + tx;
    }

    static DetectionResult failure(String typeLabel, String reason) {
        DetectionResult r = new DetectionResult();
        r.ip = "";
        r.countryCode = "--";
        r.typeLabel = typeLabel;
        r.qualityLabel = "--";
        r.organization = "--";
        r.failed = true;
        r.cacheable = false;
        r.details = "时间：" + now() + "\n结果：" + typeLabel + "（5 分钟内不自动重试）\n原因：" + reason;
        return r;
    }

    private static String now() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(new Date());
    }
}
