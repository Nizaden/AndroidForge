package com.nizen.ipcheck;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.TrafficStats;
import android.os.SystemClock;

import org.json.JSONObject;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.net.ssl.SSLException;

/** 一次完整检测：只在用户点击时运行，总时长上限约 9 秒。 */
final class IpChecker {
    static final String CF_TRACE = "https://www.cloudflare.com/cdn-cgi/trace";
    static final String TOR_API = "https://check.torproject.org/api/ip";
    static final String IPWHO_FIELDS = "?fields=success,message,ip,country_code,connection";

    private static final long TOTAL_BUDGET_MS = 9000;
    private static final int CONNECT_MS = 3000;
    private static final int READ_MS = 3000;
    private static final long DEBOUNCE_MS = 20000;

    private static final Object LOCK = new Object();
    private static boolean running;
    private static long runningSince;

    static final class DetectionResult {
        String ip;
        String countryCode;
        String typeLabel;
        String qualityLabel;
        String organization;
        String details;
    }

    private IpChecker() {
    }

    /** pending 可以为 null（从 App 页面触发时）。 */
    static void startRefresh(Context context, final BroadcastReceiver.PendingResult pending) {
        final Context app = context.getApplicationContext();
        synchronized (LOCK) {
            long now = SystemClock.elapsedRealtime();
            if (running && now - runningSince < DEBOUNCE_MS) {
                finishQuietly(pending); // 正在检测，忽略重复点击
                return;
            }
            running = true;
            runningSince = now;
        }
        WidgetRenderer.renderAll(app, true);
        Thread worker = new Thread(() -> {
            try {
                DetectionResult r = detect(app);
                Store.save(app, r);
            } catch (Throwable t) {
                DetectionResult r = failure("检测失败", "程序异常：" + t.getClass().getSimpleName());
                Store.save(app, r);
            } finally {
                synchronized (LOCK) {
                    running = false;
                }
                try {
                    WidgetRenderer.renderAll(app, false);
                } catch (Throwable ignored) {
                    // 渲染失败不影响 finish
                }
                finishQuietly(pending);
            }
        }, "ip-check");
        worker.start();
    }

    private static void finishQuietly(BroadcastReceiver.PendingResult pending) {
        if (pending != null) {
            try {
                pending.finish();
            } catch (Throwable ignored) {
                // 已结束
            }
        }
    }

    static DetectionResult detect(Context app) {
        if (!hasNetwork(app)) {
            return failure("无网络", "没有可用网络");
        }
        final long start = SystemClock.elapsedRealtime();
        final long deadline = start + TOTAL_BUDGET_MS;
        final long bytesBefore = uidBytes();
        StringBuilder log = new StringBuilder();
        ExecutorService pool = Executors.newFixedThreadPool(8);
        try {
            // 1. 先确定出口 IP（Cloudflare，纯文本约 300 字节）
            Callable<String> traceTask = () -> Http.get(CF_TRACE, CONNECT_MS, READ_MS, 4096);
            Future<String> fTrace = pool.submit(traceTask);
            String traceBody = await(fTrace, Math.min(deadline, start + 4000), "Cloudflare", log);
            Map<String, String> trace = traceBody == null ? null : parseTrace(traceBody);
            String ip = trace == null ? null : normalizeIp(trace.get("ip"));
            if (trace != null) {
                log.append("Cloudflare：成功，warp=").append(nz(trace.get("warp")))
                        .append("，loc=").append(nz(trace.get("loc"))).append('\n');
            }

            JSONObject who = null;
            if (ip == null) {
                // 备用：ipwho.is 直接返回调用方 IP
                Future<JSONObject> fSelf = submitJson(pool, "https://ipwho.is/" + IPWHO_FIELDS);
                who = await(fSelf, deadline, "ipwho.is(备用)", log);
                if (who != null && who.optBoolean("success", false)) {
                    ip = normalizeIp(who.optString("ip", null));
                }
            }
            if (ip == null) {
                return failure("检测失败", log.append("无法获取出口 IP").toString());
            }

            // 2. 用同一个 IP 并行查询各数据源 + 线路质量测试
            final String fip = ip;
            Future<JSONObject> fIq = submitJson(pool, "https://api.ipquery.io/" + fip + "?format=json");
            Future<JSONObject> fPc = submitJson(pool, "https://proxycheck.io/v2/" + fip + "?vpn=1&asn=1");
            Future<JSONObject> fWho = who == null ? submitJson(pool, "https://ipwho.is/" + fip + IPWHO_FIELDS) : null;
            Future<JSONObject> fTor = submitJson(pool, TOR_API);
            Callable<QualityTester.Quality> qTask = () -> QualityTester.run(deadline - 300);
            Future<QualityTester.Quality> fQ = pool.submit(qTask);

            JSONObject iq = await(fIq, deadline, "ipquery", log);
            JSONObject pc = await(fPc, deadline, "proxycheck", log);
            if (fWho != null) {
                who = await(fWho, deadline, "ipwho.is", log);
            }
            JSONObject tor = await(fTor, deadline, "Tor 官方", log);
            QualityTester.Quality quality = await(fQ, deadline, "线路测试", log);

            // 3. 解析并交叉校验
            Classifier.Signals s = new Classifier.Signals();
            StringBuilder names = new StringBuilder();
            String org = null;
            String cc = null;

            if (trace != null) {
                s.cfOk = true;
                s.cfWarp = nz(trace.get("warp")).toLowerCase(Locale.ROOT);
                String loc = nz(trace.get("loc")).toUpperCase(Locale.ROOT);
                s.cfTorLoc = "T1".equals(loc);
                cc = validCountry(loc);
            }

            // ipquery
            if (iq != null) {
                String rip = normalizeIp(iq.optString("ip", null));
                JSONObject risk = iq.optJSONObject("risk");
                if (rip != null && !rip.equals(ip)) {
                    log.append("ipquery：IP 不一致，已忽略\n");
                } else if (risk == null) {
                    log.append("ipquery：缺少 risk 字段，已忽略\n");
                } else {
                    s.iqOk = true;
                    s.iqDc = risk.optBoolean("is_datacenter", false);
                    s.iqVpn = risk.optBoolean("is_vpn", false);
                    s.iqProxy = risk.optBoolean("is_proxy", false);
                    s.iqTor = risk.optBoolean("is_tor", false);
                    s.iqMobile = risk.optBoolean("is_mobile", false);
                    JSONObject isp = iq.optJSONObject("isp");
                    if (isp != null) {
                        org = firstNonEmpty(org, isp.optString("org", null));
                        appendName(names, isp.optString("org", null));
                        appendName(names, isp.optString("isp", null));
                    }
                    JSONObject location = iq.optJSONObject("location");
                    if (cc == null && location != null) {
                        cc = validCountry(location.optString("country_code", null));
                    }
                    log.append("ipquery：成功，机房=").append(yn(s.iqDc)).append("，VPN=").append(yn(s.iqVpn))
                            .append("，代理=").append(yn(s.iqProxy)).append("，Tor=").append(yn(s.iqTor))
                            .append("，移动=").append(yn(s.iqMobile)).append('\n');
                }
            }

            // proxycheck
            if (pc != null) {
                String status = pc.optString("status", "");
                JSONObject rec = "ok".equals(status) || "warning".equals(status) ? findRecord(pc, ip) : null;
                if (rec == null) {
                    log.append("proxycheck：无有效结果（status=").append(status).append("）\n");
                } else {
                    s.pcOk = true;
                    s.pcProxy = "yes".equalsIgnoreCase(rec.optString("proxy", ""));
                    s.pcType = rec.optString("type", "");
                    s.pcHasOperator = rec.optJSONObject("operator") != null;
                    appendName(names, rec.optString("provider", null));
                    appendName(names, rec.optString("organisation", null));
                    appendName(names, rec.optString("hostname", null));
                    if (cc == null) {
                        cc = validCountry(rec.optString("isocode", null));
                    }
                    log.append("proxycheck：成功，proxy=").append(rec.optString("proxy", "?"))
                            .append("，type=").append(s.pcType)
                            .append(s.pcHasOperator ? "，有 VPN 运营商信息" : "").append('\n');
                }
            }

            // ipwho.is（主要取组织名称）
            if (who != null) {
                String rip = normalizeIp(who.optString("ip", null));
                if (!who.optBoolean("success", false)) {
                    log.append("ipwho.is：失败（").append(who.optString("message", "")).append("）\n");
                } else if (rip != null && !rip.equals(ip)) {
                    log.append("ipwho.is：IP 不一致，已忽略\n");
                } else {
                    JSONObject conn = who.optJSONObject("connection");
                    if (conn != null) {
                        // 组织名称优先用 ipwho.is
                        String wOrg = emptyToNull(conn.optString("org", null));
                        if (wOrg != null) org = wOrg;
                        appendName(names, conn.optString("org", null));
                        appendName(names, conn.optString("isp", null));
                        org = firstNonEmpty(org, conn.optString("isp", null));
                    }
                    if (cc == null) {
                        cc = validCountry(who.optString("country_code", null));
                    }
                    log.append("ipwho.is：成功\n");
                }
            }

            // Tor 官方（只认同一个 IP 的结果）
            if (tor != null) {
                String rip = normalizeIp(tor.optString("IP", null));
                if (rip != null && rip.equals(ip) && tor.has("IsTor")) {
                    s.torOfficial = tor.optBoolean("IsTor", false);
                    log.append("Tor 官方：成功，IsTor=").append(yn(s.torOfficial)).append('\n');
                } else {
                    log.append("Tor 官方：看到的 IP 不同（可能是 IPv4/IPv6 不同），已忽略\n");
                }
            }

            if (org == null && pc != null) {
                JSONObject rec = findRecord(pc, ip);
                if (rec != null) {
                    org = firstNonEmpty(emptyToNull(rec.optString("organisation", null)),
                            rec.optString("provider", null));
                }
            }
            s.names = names.toString();

            Classifier.Verdict verdict = Classifier.classify(s);

            DetectionResult r = new DetectionResult();
            r.ip = ip;
            r.countryCode = cc == null ? "--" : cc;
            r.typeLabel = verdict.label;
            r.qualityLabel = quality == null ? "--" : quality.label;
            r.organization = org == null ? "--" : org;

            long bytesAfter = uidBytes();
            String traffic = (bytesBefore >= 0 && bytesAfter >= bytesBefore)
                    ? "约 " + ((bytesAfter - bytesBefore + 512) / 1024) + " KB" : "系统不支持统计";
            long cost = SystemClock.elapsedRealtime() - start;

            r.details = "时间：" + now() + "\n"
                    + "IP：" + ip + "\n"
                    + "国家：" + r.countryCode + "\n"
                    + "类型：" + r.typeLabel + "\n"
                    + "判断依据：" + verdict.reason + "\n"
                    + "质量：" + (quality == null ? "--（测试超时）" : quality.describe()) + "\n"
                    + "组织：" + r.organization + "\n"
                    + "本次流量：" + traffic + "，耗时 " + cost + "ms\n"
                    + "各数据源：\n" + log;
            return r;
        } finally {
            pool.shutdownNow();
        }
    }

    private static Future<JSONObject> submitJson(ExecutorService pool, final String url) {
        Callable<JSONObject> task = () -> Http.getJson(url, CONNECT_MS, READ_MS);
        return pool.submit(task);
    }

    private static <T> T await(Future<T> f, long deadline, String name, StringBuilder log) {
        if (f == null) return null;
        long wait = deadline - SystemClock.elapsedRealtime();
        try {
            if (wait <= 0) {
                throw new TimeoutException();
            }
            return f.get(wait, TimeUnit.MILLISECONDS);
        } catch (TimeoutException e) {
            f.cancel(true);
            log.append(name).append("：超时\n");
        } catch (ExecutionException e) {
            log.append(name).append("：").append(describe(e.getCause())).append('\n');
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.append(name).append("：被中断\n");
        } catch (CancellationException e) {
            log.append(name).append("：已取消\n");
        }
        return null;
    }

    private static String describe(Throwable t) {
        if (t == null) return "未知错误";
        if (t instanceof SocketTimeoutException) return "超时";
        if (t instanceof UnknownHostException) return "无法解析域名";
        if (t instanceof SSLException) return "加密连接失败";
        if (t instanceof IOException && t.getMessage() != null) return t.getMessage();
        return t.getClass().getSimpleName();
    }

    private static JSONObject findRecord(JSONObject pc, String ip) {
        JSONObject rec = pc.optJSONObject(ip);
        if (rec != null) return rec;
        Iterator<String> keys = pc.keys();
        while (keys.hasNext()) {
            String k = keys.next();
            JSONObject o = pc.optJSONObject(k);
            if (o != null && o.has("proxy") && ip.equals(normalizeIp(k))) {
                return o;
            }
        }
        return null;
    }

    static Map<String, String> parseTrace(String body) {
        Map<String, String> m = new HashMap<>();
        for (String line : body.split("\n")) {
            int i = line.indexOf('=');
            if (i > 0) {
                m.put(line.substring(0, i).trim(), line.substring(i + 1).trim());
            }
        }
        return m;
    }

    static String normalizeIp(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        if (s.isEmpty() || s.length() > 64) return null;
        if (s.indexOf(':') >= 0) {
            if (!s.matches("[0-9a-fA-F:.]+")) return null;
        } else {
            String[] parts = s.split("\\.");
            if (parts.length != 4) return null;
            for (String p : parts) {
                if (p.isEmpty() || p.length() > 3 || !p.matches("\\d+") || Integer.parseInt(p) > 255) {
                    return null;
                }
            }
        }
        try {
            return InetAddress.getByName(s).getHostAddress();
        } catch (Exception e) {
            return null;
        }
    }

    private static String validCountry(String raw) {
        if (raw == null) return null;
        String c = raw.trim().toUpperCase(Locale.ROOT);
        if (!c.matches("[A-Z]{2}")) return null;
        if ("XX".equals(c) || "T1".equals(c) || "ZZ".equals(c)) return null;
        return c;
    }

    private static boolean hasNetwork(Context app) {
        try {
            ConnectivityManager cm = app.getSystemService(ConnectivityManager.class);
            if (cm == null) return true; // 拿不到就照常尝试
            Network n = cm.getActiveNetwork();
            return n != null;
        } catch (Exception e) {
            return true;
        }
    }

    private static long uidBytes() {
        int uid = android.os.Process.myUid();
        long rx = TrafficStats.getUidRxBytes(uid);
        long tx = TrafficStats.getUidTxBytes(uid);
        if (rx == TrafficStats.UNSUPPORTED || tx == TrafficStats.UNSUPPORTED) return -1;
        return rx + tx;
    }

    static DetectionResult failure(String typeLabel, String reason) {
        DetectionResult r = new DetectionResult();
        r.ip = "";
        r.countryCode = "--";
        r.typeLabel = typeLabel;
        r.qualityLabel = "--";
        r.organization = "--";
        r.details = "时间：" + now() + "\n结果：" + typeLabel + "\n原因：" + reason;
        return r;
    }

    private static String now() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(new Date());
    }

    private static void appendName(StringBuilder sb, String s) {
        if (s != null && !s.trim().isEmpty()) {
            sb.append(s.trim()).append(" | ");
        }
    }

    private static String firstNonEmpty(String a, String b) {
        String x = emptyToNull(a);
        return x != null ? x : emptyToNull(b);
    }

    private static String emptyToNull(String s) {
        if (s == null) return null;
        String t = s.trim();
        return t.isEmpty() || "null".equalsIgnoreCase(t) ? null : t;
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    private static String yn(boolean b) {
        return b ? "是" : "否";
    }
}
