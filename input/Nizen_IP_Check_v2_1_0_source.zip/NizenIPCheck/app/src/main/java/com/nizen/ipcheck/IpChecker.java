package com.nizen.ipcheck;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.TrafficStats;
import android.os.SystemClock;

import org.json.JSONObject;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLException;

/**
 * 一次检测（参考 FlClash lib/common/ip_quality.dart 的分批做法）：
 * 1. 第一批同时问 ident.me、ip-api.com、ipquery。这三个地址只有 IPv4 解析
 *    （4.ident.me / ip-api.com / api.ipquery.io 都没有 AAAA 记录），所以连接一定走 IPv4，
 *    拿到的就是 IPv4 出口。谁先给出明确类型就用谁，并取消其余请求。
 * 2. 1 秒内没有明确类型（或已经有了答案）→ 问 proxycheck v3，用来判断干净程度。
 *    proxycheck 用不了（每日免费次数用完等）→ 改用 ipquery 的风险分。
 * 3. ident.me 没给组织名 → 用 ipwho.is 补。
 * 4. 第一批完全拿不到 IPv4 → 认为是纯 IPv6 网络，改问 6.ident.me，再用 IPv6 查其他网站。
 * 同一 IP 的结果缓存 1 天；整次失败后 5 分钟内不自动重试；429 不重试。
 */
final class IpChecker {
    static final String URL_IDENT4 = "https://4.ident.me/json";
    static final String URL_IDENT6 = "https://6.ident.me/json";
    static final String IPAPI_FIELDS = "?fields=status,message,query,countryCode,isp,org,mobile,proxy,hosting";
    /** 唯一的明文地址（ip-api.com 免费版不支持 HTTPS） */
    static final String URL_IPAPI_SELF = "http://ip-api.com/json/" + IPAPI_FIELDS;
    static final String URL_IPQUERY_SELF = "https://api.ipquery.io/?format=json";

    static String urlIpQuery(String ip) {
        return "https://api.ipquery.io/" + ip + "?format=json";
    }

    static String urlProxyCheck(String ip) {
        return "https://proxycheck.io/v3/" + ip + "?p=0";
    }

    static String urlIpWho(String ip) {
        return "https://ipwho.is/" + ip + "?fields=success,message,ip,country_code,connection";
    }

    private static final long TOTAL_BUDGET_MS = 9000;
    private static final long HEDGE_MS = 1000;
    private static final int CONNECT_MS = 3000;
    private static final int READ_MS = 3000;
    private static final long DEBOUNCE_MS = 20000;
    private static final long DEFAULT_429_COOLDOWN_MS = 10L * 60 * 1000;

    private static final Object LOCK = new Object();
    private static boolean running;
    private static long runningSince;

    static final class DetectionResult {
        String ip;
        String countryCode;
        String typeLabel;
        String qualityLabel;
        String organization;
        String details;
        /** 整次失败（5 分钟内不自动重试） */
        boolean failed;
        /** 可以按 IP 缓存 1 天 */
        boolean cacheable;
        boolean fromCache;
        long cacheAgeMs;
    }

    /** 每个具体请求。firstWave = 属于第一批（拿到明确类型后会被取消）。 */
    enum Task {
        IDENT4(Sources.Id.IDENT, true, "ident.me(IPv4)"),
        IPAPI(Sources.Id.IPAPI, true, "ip-api.com"),
        IPQUERY_SELF(Sources.Id.IPQUERY, true, "ipquery"),
        IDENT6(Sources.Id.IDENT, false, "ident.me(IPv6)"),
        IPQUERY_IP(Sources.Id.IPQUERY, false, "ipquery"),
        PROXYCHECK(Sources.Id.PROXYCHECK, false, "proxycheck"),
        IPWHO(Sources.Id.IPWHO, false, "ipwho.is");

        final Sources.Id id;
        final boolean firstWave;
        final String label;

        Task(Sources.Id id, boolean firstWave, String label) {
            this.id = id;
            this.firstWave = firstWave;
            this.label = label;
        }
    }

    private IpChecker() {
    }

    /**
     * pending 可以为 null（从 App 页面触发时）。
     * force=true：App 里的「重新检测」，跳过缓存和失败等待（限流冷却仍然遵守）。
     */
    static void startRefresh(Context context, final BroadcastReceiver.PendingResult pending, final boolean force) {
        final Context app = context.getApplicationContext();
        if (!force && Store.failureBackoffLeft(app) > 0) {
            // 上次失败不到 5 分钟，不重试
            WidgetRenderer.renderAll(app, false);
            finishQuietly(pending);
            return;
        }
        synchronized (LOCK) {
            long now = SystemClock.elapsedRealtime();
            if (running && now - runningSince < DEBOUNCE_MS) {
                finishQuietly(pending); // 正在检测，忽略重复点击
                return;
            }
            running = true;
            runningSince = now;
        }
        WidgetRenderer.renderAll(app, true);
        Thread worker = new Thread(() -> {
            try {
                DetectionResult r = new Run(app, force).execute();
                Store.save(app, r);
            } catch (Throwable t) {
                Store.save(app, failure("检测失败", "程序异常：" + t.getClass().getSimpleName()));
            } finally {
                synchronized (LOCK) {
                    running = false;
                }
                try {
                    WidgetRenderer.renderAll(app, false);
                } catch (Throwable ignored) {
                    // 渲染失败不影响 finish
                }
                finishQuietly(pending);
            }
        }, "ip-check");
        worker.start();
    }

    static boolean isRunning() {
        synchronized (LOCK) {
            return running;
        }
    }

    private static void finishQuietly(BroadcastReceiver.PendingResult pending) {
        if (pending != null) {
            try {
                pending.finish();
            } catch (Throwable ignored) {
                // 已结束
            }
        }
    }

    private static final class Answer {
        final Task task;
        final Sources.Data data;
        final Throwable error;
        /** ip-api.com 返回 X-Rl=0 时，成功也要按 X-Ttl 冷却 */
        final long rateLimitMs;

        Answer(Task task, Sources.Data data, Throwable error, long rateLimitMs) {
            this.task = task;
            this.data = data;
            this.error = error;
            this.rateLimitMs = rateLimitMs;
        }
    }

    /** 一次检测的全部状态。只有调用 execute() 的线程会读写这些字段。 */
    private static final class Run {
        final Context app;
        final boolean force;
        final long start = SystemClock.elapsedRealtime();
        final long deadline = start + TOTAL_BUDGET_MS;
        final long hedgeAt = start + HEDGE_MS;
        final ExecutorService pool = Executors.newFixedThreadPool(Task.values().length);
        final LinkedBlockingQueue<Answer> queue = new LinkedBlockingQueue<>();
        final EnumMap<Task, Http.Call> pending = new EnumMap<>(Task.class);
        final EnumSet<Task> launched = EnumSet.noneOf(Task.class);
        final List<Sources.Data> accepted = new ArrayList<>();
        final StringBuilder log = new StringBuilder();
        String ip;
        boolean decided;
        boolean secondStarted;
        boolean triedV6;

        Run(Context app, boolean force) {
            this.app = app;
            this.force = force;
        }

        DetectionResult execute() {
            try {
                return doExecute();
            } finally {
                for (Http.Call c : pending.values()) c.cancel();
                pending.clear();
                pool.shutdownNow();
            }
        }

        private DetectionResult doExecute() {
            if (!hasNetwork(app)) return failure("无网络", "没有可用网络");
            final long bytesBefore = uidBytes();
            log(force ? "手动重新检测（跳过缓存）" : "检测开始");
            log("第一批（同时）：ident.me、ip-api.com、ipquery（均只走 IPv4）");
            launch(Task.IDENT4, URL_IDENT4);
            launch(Task.IPAPI, URL_IPAPI_SELF);
            launch(Task.IPQUERY_SELF, URL_IPQUERY_SELF);

            while (true) {
                long now = SystemClock.elapsedRealtime();
                if (ip != null && !secondStarted && (decided || now >= hedgeAt || !firstWavePending())) {
                    startSecond(now);
                }
                if (secondStarted) maybeLaunchIpWho();
                if (pending.isEmpty()) {
                    if (ip == null && !triedV6) {
                        triedV6 = true;
                        log("没拿到 IPv4，按纯 IPv6 网络处理");
                        if (launch(Task.IDENT6, URL_IDENT6)) continue;
                    }
                    break;
                }
                if (now >= deadline) {
                    for (Task t : new ArrayList<>(pending.keySet())) cancel(t, "超时，放弃");
                    break;
                }
                long until = deadline;
                if (ip != null && !secondStarted) until = Math.min(until, hedgeAt);
                Answer a;
                try {
                    a = queue.poll(Math.max(1, until - now), TimeUnit.MILLISECONDS);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
                if (a == null) continue;
                if (pending.remove(a.task) == null) continue; // 已取消的请求，结果丢弃
                DetectionResult hit = handle(a);
                if (hit != null) return hit;
            }
            return build(bytesBefore);
        }

        private boolean firstWavePending() {
            for (Task t : pending.keySet()) {
                if (t.firstWave) return true;
            }
            return false;
        }

        private void startSecond(long now) {
            secondStarted = true;
            String why = decided ? "已有类型，查干净程度"
                    : (now >= hedgeAt ? "1 秒内没有明确类型" : "第一批都没有明确类型");
            log("第二批：proxycheck（" + why + "）");
            if (!launch(Task.PROXYCHECK, urlProxyCheck(ip))) {
                ensureIpQuery("proxycheck 暂不可用，改用 ipquery 的风险分");
            }
            if (!isIpv4(ip)) ensureIpQuery("IPv6：用 ipquery 补充数据");
        }

        private void maybeLaunchIpWho() {
            if (ip == null || launched.contains(Task.IPWHO)) return;
            if (pending.containsKey(Task.IDENT4) || pending.containsKey(Task.IDENT6)) return; // 等 ident.me
            Sources.Data id = Classifier.find(accepted, Sources.Id.IDENT);
            if (id != null && id.org != null) return;
            log("ident.me 没给组织名，用 ipwho.is 补");
            launch(Task.IPWHO, urlIpWho(ip));
        }

        private void ensureIpQuery(String why) {
            if (ip == null) return;
            if (Classifier.find(accepted, Sources.Id.IPQUERY) != null) return;
            if (pending.containsKey(Task.IPQUERY_SELF) || launched.contains(Task.IPQUERY_IP)) return;
            log(why);
            launch(Task.IPQUERY_IP, urlIpQuery(ip));
        }

        /** 返回 false 表示因冷却跳过，没有发出请求。 */
        private boolean launch(final Task t, final String url) {
            if (launched.contains(t)) return false;
            launched.add(t);
            String skip = Store.skipReason(app, t.id, force);
            if (skip != null) {
                log(t.label + "：跳过，" + skip);
                return false;
            }
            final Http.Call call = new Http.Call();
            final String queriedIp = ip;
            pending.put(t, call);
            pool.execute(() -> {
                try {
                    Http.Response r = Http.get(url, CONNECT_MS, READ_MS, call);
                    Sources.Data d = parse(t, r, queriedIp);
                    long rl = 0;
                    if (t.id == Sources.Id.IPAPI && "0".equals(trim(r.xRl))) {
                        long s = Http.seconds(r.xTtl);
                        rl = (s > 0 ? s : 60) * 1000L;
                    }
                    queue.add(new Answer(t, d, null, rl));
                } catch (Throwable e) {
                    queue.add(new Answer(t, null, e, 0));
                }
            });
            return true;
        }

        private void cancel(Task t, String why) {
            Http.Call c = pending.remove(t);
            if (c != null) {
                c.cancel();
                log(t.label + "：" + why);
            }
        }

        /** 处理一个结果；命中缓存时返回缓存结果。 */
        private DetectionResult handle(Answer a) {
            Task t = a.task;
            if (a.error != null) {
                Throwable e = a.error;
                if (e instanceof Http.RateLimitedException) {
                    Store.coolDown(app, t.id, ((Http.RateLimitedException) e).coolDownMs, true, e.getMessage());
                    log(t.label + "：" + e.getMessage() + "，不重试");
                } else {
                    String m = describe(e);
                    Store.coolDown(app, t.id, Store.FAIL_BACKOFF_MS, false, m);
                    log(t.label + "：" + m);
                }
                if (t == Task.PROXYCHECK) ensureIpQuery("proxycheck 不可用，改用 ipquery 的风险分");
                return null;
            }
            if (a.rateLimitMs > 0) {
                Store.coolDown(app, t.id, a.rateLimitMs, true, "本分钟次数已用完");
            } else {
                Store.clearCoolDown(app, t.id);
            }

            Sources.Data d = a.data;
            String rip = normalizeIp(d.ip);
            if (rip == null) {
                log(t.label + "：没返回有效 IP，已忽略");
                return null;
            }
            if (ip == null) {
                if (t != Task.IDENT6 && !isIpv4(rip)) {
                    log(t.label + "：返回的是 IPv6，已忽略");
                    return null;
                }
                ip = rip;
                log("出口 IP（" + (isIpv4(ip) ? "IPv4" : "IPv6") + "）来自 " + t.label);
                if (!force) {
                    DetectionResult c = Store.cached(app, ip);
                    if (c != null) {
                        for (Task p : new ArrayList<>(pending.keySet())) cancel(p, "已有 1 天内的缓存，取消");
                        long min = c.cacheAgeMs / 60000;
                        c.details = "（缓存结果：" + (min / 60) + " 小时 " + (min % 60)
                                + " 分钟前检测。同一 IP 1 天内不重复查询，要重查请在 App 里点「重新检测」）\n"
                                + c.details;
                        return c;
                    }
                }
            }
            if (!rip.equals(ip)) {
                log(t.label + "：看到的 IP 不一致（" + rip + "），已忽略");
                return null;
            }
            accepted.add(d);
            log(t.label + "：" + d.summary);
            if (!decided && d.definitive()) {
                decided = true;
                log("→ 先到先用：" + t.label + " 明确给出「" + Sources.typeName(d.type) + "」");
                for (Task p : new ArrayList<>(pending.keySet())) {
                    if (p.firstWave) cancel(p, "已有明确类型，取消");
                }
            }
            if (t == Task.PROXYCHECK && d.risk < 0) ensureIpQuery("proxycheck 没给风险分，改用 ipquery");
            return null;
        }

        private DetectionResult build(long bytesBefore) {
            if (ip == null) {
                DetectionResult f = failure("检测失败", "无法获取出口 IP\n" + log);
                return f;
            }
            Classifier.Verdict type = Classifier.decideType(accepted);
            Classifier.Verdict quality = Classifier.decideQuality(accepted);

            DetectionResult r = new DetectionResult();
            r.ip = ip;
            String cc = pickCountry();
            String org = pickOrg();
            r.countryCode = cc == null ? "--" : cc;
            r.typeLabel = type.label;
            r.qualityLabel = quality.label;
            r.organization = org == null ? "--" : org;
            r.cacheable = !("未知".equals(type.label) && "未知".equals(quality.label));
            r.failed = !r.cacheable;

            long bytesAfter = uidBytes();
            String traffic = (bytesBefore >= 0 && bytesAfter >= bytesBefore)
                    ? "约 " + ((bytesAfter - bytesBefore + 512) / 1024) + " KB" : "系统不支持统计";
            long cost = SystemClock.elapsedRealtime() - start;
            r.details = "时间：" + now() + "\n"
                    + "IP：" + ip + (isIpv4(ip) ? "（IPv4）" : "（IPv6，没有 IPv4 出口）") + "\n"
                    + "国家：" + r.countryCode + "\n"
                    + "类型：" + r.typeLabel + "\n"
                    + "类型依据：" + type.reason + "\n"
                    + "质量：" + r.qualityLabel + "\n"
                    + "质量依据：" + quality.reason + "\n"
                    + "组织：" + r.organization + "\n"
                    + "本次流量：" + traffic + "，耗时 " + cost + "ms\n"
                    + (r.failed ? "数据不足，5 分钟内不自动重试\n" : "")
                    + "过程：\n" + log;
            return r;
        }

        private String pickOrg() {
            Sources.Id[] order = {Sources.Id.IDENT, Sources.Id.IPWHO, Sources.Id.IPQUERY,
                    Sources.Id.PROXYCHECK, Sources.Id.IPAPI};
            for (Sources.Id id : order) {
                Sources.Data d = Classifier.find(accepted, id);
                if (d != null && d.org != null) return d.org;
            }
            return null;
        }

        private String pickCountry() {
            Sources.Id[] order = {Sources.Id.IDENT, Sources.Id.IPQUERY, Sources.Id.PROXYCHECK,
                    Sources.Id.IPAPI, Sources.Id.IPWHO};
            for (Sources.Id id : order) {
                Sources.Data d = Classifier.find(accepted, id);
                String c = d == null ? null : validCountry(d.cc);
                if (c != null) return c;
            }
            return null;
        }

        private void log(String s) {
            log.append("[+").append(SystemClock.elapsedRealtime() - start).append("ms] ")
                    .append(s).append('\n');
        }
    }

    private static Sources.Data parse(Task t, Http.Response r, String queriedIp) throws IOException {
        if (r.code == 429) {
            long s = Http.seconds(t.id == Sources.Id.IPAPI ? r.xTtl : r.retryAfter);
            if (s <= 0) s = Http.seconds(r.retryAfter);
            long cd = s > 0 ? s * 1000L
                    : (t.id == Sources.Id.PROXYCHECK ? Sources.PROXYCHECK_DENIED_COOLDOWN_MS : DEFAULT_429_COOLDOWN_MS);
            throw new Http.RateLimitedException("HTTP 429 限流", cd);
        }
        if (t.id == Sources.Id.PROXYCHECK && (r.code == 401 || r.code == 403)) {
            String msg = "";
            try {
                msg = new JSONObject(r.body).optString("message", "");
            } catch (Exception ignored) {
                // 没有 JSON 也按被拒绝处理
            }
            throw new Http.RateLimitedException("被拒绝（HTTP " + r.code + "）" + msg,
                    Sources.PROXYCHECK_DENIED_COOLDOWN_MS);
        }
        if (r.code < 200 || r.code > 299) throw new IOException("HTTP " + r.code);
        JSONObject j = Sources.json(r.body);
        switch (t.id) {
            case IDENT:
                return Sources.parseIdent(j);
            case IPAPI:
                return Sources.parseIpApi(j);
            case IPQUERY:
                return Sources.parseIpQuery(j);
            case PROXYCHECK:
                return Sources.parseProxyCheck(j, queriedIp);
            default:
                return Sources.parseIpWho(j);
        }
    }

    private static String describe(Throwable t) {
        if (t == null) return "未知错误";
        if (t instanceof SocketTimeoutException) return "超时";
        if (t instanceof UnknownHostException) return "无法解析域名";
        if (t instanceof SSLException) return "加密连接失败";
        if (t instanceof IOException && t.getMessage() != null) return t.getMessage();
        return t.getClass().getSimpleName();
    }

    static boolean isIpv4(String ip) {
        return ip != null && ip.indexOf(':') < 0;
    }

    static String normalizeIp(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        if (s.isEmpty() || s.length() > 64) return null;
        if (s.indexOf(':') >= 0) {
            if (!s.matches("[0-9a-fA-F:.]+")) return null;
        } else {
            String[] parts = s.split("\\.");
            if (parts.length != 4) return null;
            for (String p : parts) {
                if (p.isEmpty() || p.length() > 3 || !p.matches("\\d+") || Integer.parseInt(p) > 255) {
                    return null;
                }
            }
        }
        try {
            return InetAddress.getByName(s).getHostAddress(); // 字面量地址，不会发起 DNS 查询
        } catch (Exception e) {
            return null;
        }
    }

    private static String validCountry(String raw) {
        if (raw == null) return null;
        String c = raw.trim().toUpperCase(Locale.ROOT);
        if (!c.matches("[A-Z]{2}")) return null;
        if ("XX".equals(c) || "T1".equals(c) || "ZZ".equals(c)) return null;
        return c;
    }

    private static String trim(String s) {
        return s == null ? null : s.trim();
    }

    private static boolean hasNetwork(Context app) {
        try {
            ConnectivityManager cm = app.getSystemService(ConnectivityManager.class);
            if (cm == null) return true; // 拿不到就照常尝试
            Network n = cm.getActiveNetwork();
            return n != null;
        } catch (Exception e) {
            return true;
        }
    }

    private static long uidBytes() {
        int uid = android.os.Process.myUid();
        long rx = TrafficStats.getUidRxBytes(uid);
        long tx = TrafficStats.getUidTxBytes(uid);
        if (rx == TrafficStats.UNSUPPORTED || tx == TrafficStats.UNSUPPORTED) return -1;
        return rx + tx;
    }

    static DetectionResult failure(String typeLabel, String reason) {
        DetectionResult r = new DetectionResult();
        r.ip = "";
        r.countryCode = "--";
        r.typeLabel = typeLabel;
        r.qualityLabel = "未知";
        r.organization = "--";
        r.failed = true;
        r.cacheable = false;
        r.details = "时间：" + now() + "\n结果：" + typeLabel + "（5 分钟内不自动重试）\n原因：" + reason;
        return r;
    }

    private static String now() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(new Date());
    }
}
