package com.nizen.ipcheck;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 各数据源的解析，逐个照搬 FlClash lib/common/ip_quality.dart
 * （_fromIdentMe / _fromIpApiCom / _fromIpQuery / _fromIpLocate / _fromProxyCheck / _fromIpApiIs、
 * _pickType、_declaredType、_flag、_text、_asn），FlClash 为 GPL-3.0。
 *
 * 额外保留（FlClash 没有）：
 * - 国家代码（小组件要显示）
 * - proxycheck / ipquery 的风险分等原始标记，只用于“机房干净程度”评级
 */
final class Sources {

    enum Id {
        IDENT("ident.me"),
        IPAPI("ip-api.com"),
        IPQUERY("ipquery.io"),
        IPLOCATE("iplocate.io"),
        PROXYCHECK("proxycheck.io"),
        IPAPIIS("ipapi.is");

        final String label;

        Id(String label) {
            this.label = label;
        }
    }

    /** FlClash IpType */
    enum Type {
        RESIDENTIAL("住宅"),
        MOBILE("移动网络"),
        BUSINESS("商业"),
        HOSTING("机房");

        final String label;

        Type(String label) {
            this.label = label;
        }
    }

    /** FlClash IpQualitySourceStatus */
    enum Status {
        NO_TYPE("没给出类型"),
        TIMEOUT("超时"),
        RATE_LIMITED("被限流 / 次数用完"),
        FAILED("失败"),
        IP_MISMATCH("IP 不一致");

        final String label;

        Status(String label) {
            this.label = label;
        }
    }

    /** FlClash IpQuality */
    static final class Quality {
        Id source;
        Type type;
        String organization;
        Integer asn;
        boolean isProxy;
        boolean isVpn;
        boolean isTor;
        boolean isAbuser;

        String flags() {
            return "代理=" + yn(isProxy) + "，VPN=" + yn(isVpn) + "，Tor=" + yn(isTor) + "，滥用=" + yn(isAbuser);
        }
    }

    /** 机房干净程度用的原始标记（proxycheck / ipquery） */
    static final class Clean {
        Id id;
        boolean proxy;
        boolean vpn;
        boolean tor;
        boolean compromised;
        boolean scraper;
        boolean anonymous;
        int risk = -1;
        int confidence = -1;
        int attacks;

        String summary() {
            if (id == Id.PROXYCHECK) {
                return "代理=" + yn(proxy) + "，VPN=" + yn(vpn) + "，Tor=" + yn(tor) + "，被入侵=" + yn(compromised)
                        + "，爬虫=" + yn(scraper) + "，匿名=" + yn(anonymous) + "，风险分=" + num(risk)
                        + "，可信度=" + num(confidence) + "，攻击记录=" + attacks;
            }
            return "代理=" + yn(proxy) + "，VPN=" + yn(vpn) + "，Tor=" + yn(tor) + "，风险分=" + num(risk);
        }
    }

    /** 一个数据源解析后的全部内容。quality == null 表示没给出类型（FlClash 的 noType）。 */
    static final class Parsed {
        Id id;
        String ip;
        String cc;
        Quality quality;
        boolean inferred;
        Clean clean;

        String summary() {
            String s = quality == null ? "没给出类型"
                    : "类型=" + quality.type.label + (inferred ? "（推断）" : "") + "，" + quality.flags();
            return clean == null ? s : s + "；" + clean.summary();
        }
    }

    /** 某个数据源失败（对应 FlClash 的 _SourceFailure）。 */
    static final class Failure extends IOException {
        final Status status;
        /** > 0 表示被限流，需要冷却这么久 */
        final long coolDownMs;

        Failure(Status status, String msg, long coolDownMs) {
            super(msg);
            this.status = status;
            this.coolDownMs = coolDownMs;
        }
    }

    /** proxycheck 配额用完 / 被拒绝后的冷却时间 */
    static final long PROXYCHECK_DENIED_COOLDOWN_MS = 60L * 60 * 1000;
    static final long DEFAULT_429_COOLDOWN_MS = 10L * 60 * 1000;

    private Sources() {
    }

    /** 对应 FlClash _query 里的状态码处理 + _parse。ip 为当前已知的出口 IP（可能为 null）。 */
    static Parsed parse(Id id, Http.Response r, String ip) throws IOException {
        if (r.code == 429) {
            long s = Http.seconds(id == Id.IPAPI ? r.xTtl : r.retryAfter);
            if (s <= 0) s = Http.seconds(r.retryAfter);
            long cd = s > 0 ? s * 1000L
                    : (id == Id.PROXYCHECK ? PROXYCHECK_DENIED_COOLDOWN_MS : DEFAULT_429_COOLDOWN_MS);
            throw new Failure(Status.RATE_LIMITED, "HTTP 429", cd);
        }
        if (id == Id.PROXYCHECK && (r.code == 401 || r.code == 403)) {
            // v3 被拒绝 / 今日免费次数用完时会给 4xx（我们自己的冷却规则，FlClash 记为失败）
            throw new Failure(Status.RATE_LIMITED, "被拒绝（HTTP " + r.code + "）", PROXYCHECK_DENIED_COOLDOWN_MS);
        }
        if (r.code != 200) {
            throw new Failure(Status.FAILED, "HTTP " + r.code, 0);
        }
        JSONObject j;
        try {
            j = new JSONObject(r.body);
        } catch (JSONException e) {
            throw new Failure(Status.FAILED, "返回的不是 JSON", 0);
        }
        switch (id) {
            case IDENT:
                return fromIdentMe(j);
            case IPAPI:
                return fromIpApiCom(j);
            case IPQUERY:
                return fromIpQuery(j);
            case IPLOCATE:
                return fromIpLocate(j);
            case PROXYCHECK:
                return fromProxyCheck(j, ip);
            default:
                return fromIpApiIs(j);
        }
    }

    // ---------- ident.me ----------
    private static Parsed fromIdentMe(JSONObject j) {
        Parsed p = base(Id.IDENT, text(j.opt("ip")), text(j.opt("cc")));
        quality(p, declaredType(j.opt("type")), false, text(j.opt("aso")), asn(j.opt("asn")),
                false, false, false, false);
        return p;
    }

    // ---------- ip-api.com ----------
    private static Parsed fromIpApiCom(JSONObject j) throws Failure {
        if (!"success".equals(j.opt("status"))) {
            throw new Failure(Status.FAILED, "status=" + j.opt("status") + " " + j.optString("message", ""), 0);
        }
        Parsed p = base(Id.IPAPI, text(j.opt("query")), text(j.opt("countryCode")));
        Type type = pickType(flag(j.opt("hosting")), flag(j.opt("mobile")), null);
        quality(p, type == null ? Type.RESIDENTIAL : type, type == null,
                first(text(j.opt("org")), text(j.opt("isp"))), asn(j.opt("as")),
                flag(j.opt("proxy")), false, false, false);
        return p;
    }

    // ---------- ipquery ----------
    private static Parsed fromIpQuery(JSONObject j) {
        JSONObject risk = object(j.opt("risk"));
        JSONObject isp = object(j.opt("isp"));
        Parsed p = base(Id.IPQUERY, text(j.opt("ip")), text(object(j.opt("location")).opt("country_code")));
        Type type = pickType(flag(risk.opt("is_datacenter")), flag(risk.opt("is_mobile")), null);
        quality(p, type == null ? Type.RESIDENTIAL : type, type == null,
                first(text(isp.opt("org")), text(isp.opt("isp"))), asn(isp.opt("asn")),
                flag(risk.opt("is_proxy")), flag(risk.opt("is_vpn")), flag(risk.opt("is_tor")), false);
        if (risk.length() > 0) {
            Clean c = new Clean();
            c.id = Id.IPQUERY;
            c.proxy = flag(risk.opt("is_proxy"));
            c.vpn = flag(risk.opt("is_vpn"));
            c.tor = flag(risk.opt("is_tor"));
            c.risk = intOr(risk.opt("risk_score"), -1);
            p.clean = c;
        }
        return p;
    }

    // ---------- iplocate.io ----------
    private static Parsed fromIpLocate(JSONObject j) {
        JSONObject privacy = object(j.opt("privacy"));
        JSONObject company = object(j.opt("company"));
        JSONObject asn = object(j.opt("asn"));
        Parsed p = base(Id.IPLOCATE, text(j.opt("ip")), text(j.opt("country_code")));
        Type declared = declaredType(company.opt("type"));
        if (declared == null) declared = declaredType(asn.opt("type"));
        quality(p, pickType(flag(privacy.opt("is_hosting")), false, declared), false,
                first(text(company.opt("name")), text(asn.opt("name"))), asn(asn.opt("asn")),
                flag(privacy.opt("is_proxy")), flag(privacy.opt("is_vpn")),
                flag(privacy.opt("is_tor")), flag(privacy.opt("is_abuser")));
        return p;
    }

    // ---------- proxycheck v3 ----------
    private static Parsed fromProxyCheck(JSONObject j, String ip) throws Failure {
        Object status = j.opt("status");
        if ("denied".equals(status)) {
            throw new Failure(Status.RATE_LIMITED, "被拒绝 / 今日免费次数用完：" + j.optString("message", ""),
                    PROXYCHECK_DENIED_COOLDOWN_MS);
        }
        if (!"ok".equals(status) && !"warning".equals(status)) {
            throw new Failure(Status.FAILED, "status=" + status, 0);
        }
        JSONObject result = object(ip == null ? null : j.opt(ip));
        if (result.length() == 0) {
            // IPv6 的键名写法可能和我们的不同，找第一个带 detections 的结果
            Iterator<String> keys = j.keys();
            while (keys.hasNext()) {
                JSONObject o = object(j.opt(keys.next()));
                if (o.has("detections")) {
                    result = o;
                    break;
                }
            }
        }
        JSONObject network = object(result.opt("network"));
        JSONObject det = object(result.opt("detections"));
        Object networkType = network.opt("type");
        Parsed p = base(Id.PROXYCHECK, ip, text(object(result.opt("location")).opt("country_code")));
        Type declared = "Residential".equals(networkType) ? Type.RESIDENTIAL
                : ("Business".equals(networkType) ? Type.BUSINESS : null);
        quality(p, pickType(flag(det.opt("hosting")) || "Hosting".equals(networkType),
                        "Wireless".equals(networkType), declared), false,
                text(network.opt("organisation")), asn(network.opt("asn")),
                flag(det.opt("proxy")), flag(det.opt("vpn")), flag(det.opt("tor")), false);
        if (det.length() > 0) {
            Clean c = new Clean();
            c.id = Id.PROXYCHECK;
            c.proxy = flag(det.opt("proxy"));
            c.vpn = flag(det.opt("vpn"));
            c.tor = flag(det.opt("tor"));
            c.compromised = flag(det.opt("compromised"));
            c.scraper = flag(det.opt("scraper"));
            c.anonymous = flag(det.opt("anonymous"));
            c.risk = intOr(det.opt("risk"), -1);
            c.confidence = intOr(det.opt("confidence"), -1);
            JSONObject attacks = object(result.opt("attack_history"));
            Iterator<String> it = attacks.keys();
            while (it.hasNext()) {
                c.attacks += Math.max(0, intOr(attacks.opt(it.next()), 0));
            }
            p.clean = c;
        }
        return p;
    }

    // ---------- ipapi.is ----------
    private static Parsed fromIpApiIs(JSONObject j) {
        JSONObject company = object(j.opt("company"));
        JSONObject asn = object(j.opt("asn"));
        Parsed p = base(Id.IPAPIIS, text(j.opt("ip")), null);
        Type declared = declaredType(company.opt("type"));
        if (declared == null) declared = declaredType(asn.opt("type"));
        quality(p, pickType(flag(j.opt("is_datacenter")), flag(j.opt("is_mobile")), declared), false,
                first(text(company.opt("name")), text(asn.opt("org"))), asn(asn.opt("asn")),
                flag(j.opt("is_proxy")), flag(j.opt("is_vpn")), flag(j.opt("is_tor")), flag(j.opt("is_abuser")));
        return p;
    }

    // ---------- FlClash 的工具函数 ----------
    private static Parsed base(Id id, String ip, String cc) {
        Parsed p = new Parsed();
        p.id = id;
        p.ip = ip;
        p.cc = cc;
        return p;
    }

    /** _quality：type 为 null 时不给结果（noType）。 */
    private static void quality(Parsed p, Type type, boolean inferred, String organization, Integer asn,
                                boolean isProxy, boolean isVpn, boolean isTor, boolean isAbuser) {
        if (type == null) return;
        Quality q = new Quality();
        q.source = p.id;
        q.type = type;
        q.organization = organization;
        q.asn = asn;
        q.isProxy = isProxy;
        q.isVpn = isVpn;
        q.isTor = isTor;
        q.isAbuser = isAbuser;
        p.quality = q;
        p.inferred = inferred;
    }

    /** _pickType */
    static Type pickType(boolean hosting, boolean mobile, Type declared) {
        if (hosting || declared == Type.HOSTING) return Type.HOSTING;
        if (mobile) return Type.MOBILE;
        return declared;
    }

    /** _declaredType */
    static Type declaredType(Object value) {
        if ("isp".equals(value)) return Type.RESIDENTIAL;
        if ("business".equals(value) || "education".equals(value)
                || "government".equals(value) || "banking".equals(value)) return Type.BUSINESS;
        if ("hosting".equals(value)) return Type.HOSTING;
        return null;
    }

    /** _object */
    static JSONObject object(Object value) {
        return value instanceof JSONObject ? (JSONObject) value : new JSONObject();
    }

    /** _flag：只认 true */
    static boolean flag(Object value) {
        return Boolean.TRUE.equals(value);
    }

    /** _text：非空字符串 */
    static String text(Object value) {
        return value instanceof String && !((String) value).isEmpty() ? (String) value : null;
    }

    private static final Pattern DIGITS = Pattern.compile("\\d+");

    /** _asn：数字，或字符串里的第一串数字；0 视为没有 */
    static Integer asn(Object value) {
        Integer n = null;
        if (value instanceof Number) {
            n = ((Number) value).intValue();
        } else if (value instanceof String) {
            Matcher m = DIGITS.matcher((String) value);
            if (m.find()) {
                try {
                    n = Integer.parseInt(m.group());
                } catch (NumberFormatException ignored) {
                    n = null;
                }
            }
        }
        return n == null || n == 0 ? null : n;
    }

    private static int intOr(Object v, int def) {
        if (v instanceof Number) return ((Number) v).intValue();
        if (v instanceof String) {
            try {
                return Integer.parseInt(((String) v).trim());
            } catch (NumberFormatException ignored) {
                return def;
            }
        }
        return def;
    }

    static String first(String a, String b) {
        return a != null ? a : b;
    }

    static String yn(boolean b) {
        return b ? "是" : "否";
    }

    private static String num(int v) {
        return v < 0 ? "无" : String.valueOf(v);
    }
}
