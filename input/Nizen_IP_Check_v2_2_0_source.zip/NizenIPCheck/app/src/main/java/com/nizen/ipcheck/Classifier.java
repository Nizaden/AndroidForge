package com.nizen.ipcheck;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * 质量评级。
 * 1. 照搬 FlClash lib/models/ip_quality.dart 的 IpQualityExt.level：
 *    Tor 或滥用 → 风险；住宅 / 移动网络 / 商业 → 优；机房 → 普通。
 * 2. 我们加的：FlClash 把机房一律评“普通”，这里对“机房、且没有 Tor/滥用”的结果，
 *    再用 proxycheck（不可用时用 ipquery 的风险分）看干净程度，仍然用 优 / 普通 / 风险 三档：
 *    - 风险：Tor、被入侵、爬虫、滥用、攻击记录 ≥10 次，或两个以上网站标了代理/VPN，或风险分高
 *    - 普通：只有一个网站标了代理/VPN，或风险分中
 *    - 优：没有任何代理/VPN 标记且风险分低（干净的机房也可以是优）
 *    - 两个都拿不到：保持 FlClash 的“普通”
 */
final class Classifier {

    static final String GOOD = "优";
    static final String NORMAL = "普通";
    static final String RISKY = "风险";

    // 风险分 0～100 平均分三档：低 0-33，中 34-66，高 67-100
    static final int RISK_LOW_MAX = 33;
    static final int RISK_MID_MAX = 66;
    /** proxycheck 可信度低于此值时，它的标记不算数 */
    static final int MIN_CONFIDENCE = 50;
    /** 攻击记录达到此次数视为滥用 */
    static final int ABUSE_ATTACKS = 10;

    static final class Verdict {
        final String label;
        final String reason;

        Verdict(String label, String reason) {
            this.label = label;
            this.reason = reason;
        }
    }

    private Classifier() {
    }

    /** FlClash IpQualityExt.level */
    static Verdict flclashLevel(Sources.Quality q) {
        if (q.isTor || q.isAbuser) {
            return new Verdict(RISKY, q.source.label + " 标了" + (q.isTor ? "Tor" : "滥用") + "（FlClash 规则）");
        }
        if (q.type == Sources.Type.HOSTING) {
            return new Verdict(NORMAL, "机房（FlClash 规则：机房一律普通）");
        }
        return new Verdict(GOOD, q.type.label + "，没有 Tor/滥用标记（FlClash 规则）");
    }

    /** 机房干净程度（我们加的） */
    static Verdict gradeHosting(Sources.Clean pc, Sources.Clean iq, Collection<Sources.Parsed> all) {
        boolean pcTrust = pc != null && (pc.confidence < 0 || pc.confidence >= MIN_CONFIDENCE);
        List<String> severe = new ArrayList<>();
        List<String> marks = new ArrayList<>();

        if (pcTrust && pc.tor) severe.add("proxycheck 标了 Tor");
        if (pcTrust && pc.compromised) severe.add("proxycheck 标了被入侵");
        if (pcTrust && pc.scraper) severe.add("proxycheck 标了爬虫");
        if (pc != null && pc.attacks >= ABUSE_ATTACKS) severe.add("攻击记录 " + pc.attacks + " 次");
        if (iq != null && iq.tor) severe.add("ipquery 标了 Tor");

        boolean ipApiProxy = false;
        for (Sources.Parsed p : all) {
            Sources.Quality q = p.quality;
            if (q == null) continue;
            if (p.id != Sources.Id.IPAPI && (q.isTor || q.isAbuser)) {
                severe.add(p.id.label + " 标了" + (q.isTor ? "Tor" : "滥用"));
            }
            if (p.id == Sources.Id.IPAPI) {
                ipApiProxy = q.isProxy;
            } else if (p.id != Sources.Id.PROXYCHECK && p.id != Sources.Id.IPQUERY && (q.isProxy || q.isVpn)) {
                marks.add(p.id.label + " 标了" + (q.isVpn ? "VPN" : "代理"));
            }
        }
        if (iq != null && (iq.vpn || iq.proxy)) marks.add("ipquery 标了" + (iq.vpn ? "VPN" : "代理"));
        if (pcTrust && (pc.proxy || pc.vpn)) marks.add("proxycheck 标了" + (pc.vpn ? "VPN" : "代理"));
        if (ipApiProxy && !marks.isEmpty()) marks.add("ip-api.com 也标了代理");

        int risk = -1;
        String riskFrom = "";
        if (pc != null && pc.risk >= 0) {
            risk = pc.risk;
            riskFrom = "proxycheck";
        } else if (iq != null && iq.risk >= 0) {
            risk = iq.risk;
            riskFrom = "ipquery（proxycheck 不可用，改用它）";
        }
        int band = risk < 0 ? -1 : (risk <= RISK_LOW_MAX ? 0 : (risk <= RISK_MID_MAX ? 1 : 2));

        if (pc == null && iq == null && severe.isEmpty() && marks.isEmpty()) {
            return new Verdict(NORMAL, "机房，但 proxycheck 和 ipquery 都没拿到数据，保持 FlClash 的普通");
        }

        String label;
        if (!severe.isEmpty() || marks.size() >= 2 || band == 2) label = RISKY;
        else if (marks.size() == 1 || band == 1) label = NORMAL;
        else label = GOOD;

        StringBuilder why = new StringBuilder("机房干净程度：");
        why.append("风险分=").append(risk < 0 ? "无" : risk + "（" + bandName(band) + "，来自 " + riskFrom + "）");
        why.append("；严重标记=").append(severe.isEmpty() ? "无" : join(severe));
        why.append("；代理/VPN 标记=").append(marks.isEmpty() ? "无" : join(marks));
        if (ipApiProxy && marks.isEmpty()) why.append("；只有 ip-api.com 标了代理（只作参考，不算）");
        if (pc != null && !pcTrust) why.append("；proxycheck 可信度低（").append(pc.confidence).append("），它的标记不算");
        return new Verdict(label, why.toString());
    }

    private static String bandName(int band) {
        return band == 0 ? "低" : (band == 1 ? "中" : (band == 2 ? "高" : "无"));
    }

    private static String join(List<String> items) {
        StringBuilder sb = new StringBuilder();
        for (String s : items) {
            if (sb.length() > 0) sb.append("、");
            sb.append(s);
        }
        return sb.toString();
    }
}
