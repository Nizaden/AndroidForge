package com.nizen.ipcheck;

import java.util.ArrayList;
import java.util.List;

/**
 * 判断规则（v2.1.0）：
 * 类型：任一网站说机房 → 机房；否则用最先给出明确类型的网站；
 *       只知道“不是机房” → 疑似住宅；数据不够 → 未知。
 *       ip-api.com 只作参考，不单独决定结果。
 * 质量：只看干不干净，不测延迟。代理/VPN/Tor 不进类型，只用来算质量。
 */
final class Classifier {

    // 风险分 0～100 平均分三档：低 0-33，中 34-66，高 67-100（可在这里调）
    static final int RISK_LOW_MAX = 33;
    static final int RISK_MID_MAX = 66;
    /** proxycheck 可信度低于此值时，它的标记只算“可疑迹象” */
    static final int MIN_CONFIDENCE = 50;
    /** 攻击记录达到此次数视为“滥用” */
    static final int ABUSE_ATTACKS = 10;

    static final class Verdict {
        String label;
        String reason;

        Verdict(String label, String reason) {
            this.label = label;
            this.reason = reason;
        }
    }

    private Classifier() {
    }

    static Sources.Data find(List<Sources.Data> list, Sources.Id id) {
        for (Sources.Data d : list) {
            if (d.id == id) return d;
        }
        return null;
    }

    // ===================== 类型 =====================
    static Verdict decideType(List<Sources.Data> list) {
        Sources.Data ia = find(list, Sources.Id.IPAPI);
        String ref = ia == null ? "" : "；ip-api.com 参考："
                + (ia.type == Sources.T_NONE ? "非机房" : Sources.typeName(ia.type));

        for (Sources.Data d : list) {
            if (!d.reference && d.type == Sources.T_HOSTING) {
                return new Verdict("机房", d.id.label + " 判定机房" + ref);
            }
        }
        for (Sources.Data d : list) { // 按到达先后
            if (d.definitive()) {
                return new Verdict(Sources.typeName(d.type),
                        d.id.label + " 最先给出明确类型：" + Sources.typeName(d.type) + ref);
            }
        }
        String inferredBy = null;
        for (Sources.Data d : list) {
            if (!d.reference && d.notHosting) {
                inferredBy = d.id.label;
                break;
            }
        }
        if (inferredBy != null) {
            if (ia != null && ia.type == Sources.T_HOSTING) {
                return new Verdict("未知", inferredBy + " 说不是机房，但 ip-api.com 说是机房，结论冲突");
            }
            return new Verdict("疑似住宅", inferredBy + " 只说明不是机房，没有明确住宅证据" + ref);
        }
        if (ia != null) {
            return new Verdict("未知", "只有 ip-api.com 的数据，它只作参考" + ref);
        }
        return new Verdict("未知", "没有拿到类型数据");
    }

    // ===================== 质量 =====================
    static Verdict decideQuality(List<Sources.Data> list) {
        Sources.Data pc = find(list, Sources.Id.PROXYCHECK);
        Sources.Data iq = find(list, Sources.Id.IPQUERY);
        Sources.Data ia = find(list, Sources.Id.IPAPI);
        if (pc == null && iq == null) {
            return new Verdict("未知", "proxycheck 和 ipquery 都没拿到数据");
        }

        int risk = -1;
        String riskFrom = "";
        if (pc != null && pc.risk >= 0) {
            risk = pc.risk;
            riskFrom = "proxycheck";
        } else if (iq != null && iq.risk >= 0) {
            risk = iq.risk;
            riskFrom = "ipquery（proxycheck 不可用，改用它）";
        }
        int band = risk < 0 ? -1 : (risk <= RISK_LOW_MAX ? 0 : (risk <= RISK_MID_MAX ? 1 : 2));

        boolean pcTrust = pc != null && (pc.confidence < 0 || pc.confidence >= MIN_CONFIDENCE);
        List<String> severe = new ArrayList<>();
        List<String> marks = new ArrayList<>();
        List<String> hints = new ArrayList<>();

        if ((iq != null && iq.tor) || (pcTrust && pc.tor)) severe.add("Tor");
        if (pcTrust && pc.compromised) severe.add("被入侵");
        if (pcTrust && pc.scraper) severe.add("爬虫/滥用");
        if (pc != null && pc.attacks >= ABUSE_ATTACKS) severe.add("滥用（攻击记录 " + pc.attacks + " 次）");

        int sites = 0;
        if (iq != null && (iq.vpn || iq.proxy)) {
            sites++;
            marks.add("ipquery 标了" + (iq.vpn ? "VPN" : "代理"));
        }
        if (pcTrust && (pc.proxy || pc.vpn)) {
            sites++;
            marks.add("proxycheck 标了" + (pc.vpn ? "VPN" : "代理"));
        }
        if (ia != null && ia.proxy) {
            if (sites > 0) {
                sites++;
                marks.add("ip-api.com 也标了代理");
            } else {
                hints.add("只有 ip-api.com 标了代理（只作参考）");
            }
        }
        if (pc != null && !pcTrust && (pc.proxy || pc.vpn || pc.tor || pc.compromised || pc.scraper)) {
            hints.add("proxycheck 有标记但可信度低（" + pc.confidence + "）");
        }
        if (pc != null && pc.anonymous && !pc.proxy && !pc.vpn && !pc.tor) {
            hints.add("proxycheck 标了匿名");
        }
        if (pc != null && pc.attacks > 0 && pc.attacks < ABUSE_ATTACKS) {
            hints.add("有 " + pc.attacks + " 次攻击记录");
        }

        String label;
        if (!severe.isEmpty() || (band == 2 && sites >= 1)) label = "很差";
        else if (sites >= 2 || band == 2) label = "较差";
        else if (sites == 1 || band == 1) label = "普通";
        else if (!hints.isEmpty() || band < 0) label = "良好";
        else label = "优秀";

        StringBuilder why = new StringBuilder();
        why.append("风险分=").append(risk < 0 ? "无" : risk + "（" + bandName(band) + "，来自 " + riskFrom + "）");
        why.append("；严重标记=").append(severe.isEmpty() ? "无" : join(severe));
        why.append("；代理/VPN 标记=").append(marks.isEmpty() ? "无" : join(marks));
        if (!hints.isEmpty()) why.append("；可疑迹象=").append(join(hints));
        return new Verdict(label, why.toString());
    }

    private static String bandName(int band) {
        return band == 0 ? "低" : (band == 1 ? "中" : (band == 2 ? "高" : "无"));
    }

    private static String join(List<String> items) {
        StringBuilder sb = new StringBuilder();
        for (String s : items) {
            if (sb.length() > 0) sb.append("、");
            sb.append(s);
        }
        return sb.toString();
    }
}
