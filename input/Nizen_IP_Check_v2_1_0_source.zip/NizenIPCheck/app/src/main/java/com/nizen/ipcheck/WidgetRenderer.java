package com.nizen.ipcheck;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.RemoteViews;

/** 只负责把保存的结果画到小组件上，不联网。 */
final class WidgetRenderer {
    static final int COLOR_BLACK = 0xFF000000;
    static final int COLOR_WHITE = 0xFFFFFFFF;

    private static final int[] TEXT_IDS = {
            R.id.country_code, R.id.ip, R.id.ip_type, R.id.quality,
            R.id.org_label, R.id.organization, R.id.organization_full
    };

    private WidgetRenderer() {
    }

    static void renderAll(Context context, boolean checking) {
        Context app = context.getApplicationContext();
        AppWidgetManager manager = AppWidgetManager.getInstance(app);
        int[] ids = manager.getAppWidgetIds(new ComponentName(app, IpWidgetProvider.class));
        if (ids == null || ids.length == 0) return;
        manager.updateAppWidget(ids, build(app, checking));
    }

    static RemoteViews build(Context context, boolean checking) {
        SharedPreferences p = Store.prefs(context);
        boolean visible = p.getBoolean(Store.K_VISIBLE, false);
        boolean expanded = p.getBoolean(Store.K_ORG_EXPANDED, false);
        int color = Store.isTextWhite(context) ? COLOR_WHITE : COLOR_BLACK;
        String ip = p.getString(Store.K_IP, "");
        if (ip == null) ip = "";
        String org = p.getString(Store.K_ORG, "--");

        RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.ip_widget);
        for (int id : TEXT_IDS) {
            v.setTextColor(id, color);
        }

        v.setTextViewText(R.id.ip, visible ? (ip.isEmpty() ? "--" : ip) : "*****");
        v.setTextViewText(R.id.country_code, p.getString(Store.K_CC, "--"));
        if (checking) {
            v.setTextViewText(R.id.ip_type, "检测中…");
            v.setTextViewText(R.id.quality, "质量 …");
        } else {
            v.setTextViewText(R.id.ip_type, p.getString(Store.K_TYPE, "未检测"));
            v.setTextViewText(R.id.quality, "质量 " + p.getString(Store.K_QUALITY, "--"));
        }

        // 组织名：收起时一行省略号，展开时最多 3 行；点一下切换
        v.setTextViewText(R.id.organization, org);
        v.setTextViewText(R.id.organization_full, org);
        v.setViewVisibility(R.id.organization, expanded ? View.GONE : View.VISIBLE);
        v.setViewVisibility(R.id.organization_full, expanded ? View.VISIBLE : View.GONE);

        v.setContentDescription(R.id.country_code, "点击刷新");
        v.setContentDescription(R.id.ip, visible ? "点击隐藏 IP" : "点击显示 IP");
        v.setContentDescription(R.id.organization, "点击展开组织名");
        v.setContentDescription(R.id.organization_full, "点击收起组织名");

        v.setOnClickPendingIntent(R.id.country_code,
                actionIntent(context, WidgetActionReceiver.ACTION_REFRESH, 1001));
        v.setOnClickPendingIntent(R.id.ip,
                actionIntent(context, WidgetActionReceiver.ACTION_TOGGLE, 1002));
        PendingIntent orgToggle = actionIntent(context, WidgetActionReceiver.ACTION_TOGGLE_ORG, 1003);
        v.setOnClickPendingIntent(R.id.organization, orgToggle);
        v.setOnClickPendingIntent(R.id.organization_full, orgToggle);
        return v;
    }

    private static PendingIntent actionIntent(Context context, String action, int requestCode) {
        Intent intent = new Intent(context, WidgetActionReceiver.class);
        intent.setAction(action);
        intent.setPackage(context.getPackageName());
        return PendingIntent.getBroadcast(context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
