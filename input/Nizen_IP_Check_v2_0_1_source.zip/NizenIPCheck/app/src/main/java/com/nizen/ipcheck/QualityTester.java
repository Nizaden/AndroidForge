package com.nizen.ipcheck;

import android.os.SystemClock;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 线路质量：对 Cloudflare 发 1 次预热 + 5 次小请求（每次约 300 字节），
 * 按 延迟中位数、抖动、成功率 综合打分。
 */
final class QualityTester {
    static final String TARGET = "https://www.cloudflare.com/cdn-cgi/trace";
    static final int SAMPLES = 5;
    static final long GAP_MS = 200;
    static final int PER_REQUEST_TIMEOUT_MS = 2000;

    // 延迟（毫秒）→ 分数
    private static final double[] LAT_X = {50, 100, 180, 300, 500, 800, 1500};
    private static final double[] LAT_Y = {100, 88, 72, 55, 35, 15, 0};
    // 抖动（毫秒）→ 分数
    private static final double[] JIT_X = {10, 30, 60, 120, 250};
    private static final double[] JIT_Y = {100, 80, 60, 35, 10};

    static final class Quality {
        int attempts = SAMPLES;
        int successes;
        long medianMs = -1;
        long jitterMs = -1;
        int score;
        String label = "很差";

        String describe() {
            if (successes == 0) {
                return label + "（全部失败，成功 0/" + attempts + "）";
            }
            return label + "（成功 " + successes + "/" + attempts
                    + "，延迟中位数 " + medianMs + "ms，抖动 " + jitterMs + "ms，评分 " + score + "）";
        }
    }

    private QualityTester() {
    }

    static Quality run(long deadlineElapsedMs) {
        Quality q = new Quality();

        // 预热：建立/复用 TLS 连接，不计入成绩
        long rem = deadlineElapsedMs - SystemClock.elapsedRealtime();
        if (rem > 800) {
            int to = (int) Math.min(PER_REQUEST_TIMEOUT_MS, rem);
            try {
                Http.get(TARGET, to, to, 4096);
            } catch (IOException ignored) {
                // 预热失败不影响后续测试
            }
        }

        List<Long> latencies = new ArrayList<>();
        for (int i = 0; i < SAMPLES; i++) {
            if (Thread.currentThread().isInterrupted()) {
                break;
            }
            rem = deadlineElapsedMs - SystemClock.elapsedRealtime();
            if (rem < 300) {
                break; // 剩余没做的次数按失败计
            }
            int to = (int) Math.min(PER_REQUEST_TIMEOUT_MS, rem);
            long start = SystemClock.elapsedRealtime();
            try {
                Http.get(TARGET, to, to, 4096);
                latencies.add(SystemClock.elapsedRealtime() - start);
            } catch (IOException ignored) {
                // 计为失败
            }
            if (i < SAMPLES - 1) {
                try {
                    Thread.sleep(GAP_MS);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }
        q.successes = latencies.size();
        grade(q, latencies);
        return q;
    }

    static void grade(Quality q, List<Long> latencies) {
        if (latencies.isEmpty()) {
            q.score = 0;
            q.label = "很差";
            return;
        }
        List<Long> sorted = new ArrayList<>(latencies);
        Collections.sort(sorted);
        int n = sorted.size();
        if (n % 2 == 1) {
            q.medianMs = sorted.get(n / 2);
        } else {
            q.medianMs = (sorted.get(n / 2 - 1) + sorted.get(n / 2)) / 2;
        }
        long sum = 0;
        for (int i = 1; i < latencies.size(); i++) {
            sum += Math.abs(latencies.get(i) - latencies.get(i - 1));
        }
        q.jitterMs = latencies.size() > 1 ? sum / (latencies.size() - 1) : 0;

        double rate = q.successes / (double) q.attempts;
        double latScore = interp(q.medianMs, LAT_X, LAT_Y);
        double jitScore = interp(q.jitterMs, JIT_X, JIT_Y);
        double total = latScore * 0.5 + jitScore * 0.2 + rate * 100.0 * 0.3;
        if (rate < 1.0) {
            total = Math.min(total, 69); // 有丢失最高只到“普通”
        }
        if (rate < 0.6) {
            total = Math.min(total, 20); // 成功率低于 60% 直接“很差”
        }
        q.score = (int) Math.round(total);
        q.label = label(q.score);
    }

    static String label(int score) {
        if (score >= 85) return "优秀";
        if (score >= 70) return "良好";
        if (score >= 55) return "普通";
        if (score >= 35) return "较差";
        return "很差";
    }

    private static double interp(double x, double[] xs, double[] ys) {
        if (x <= xs[0]) return ys[0];
        for (int i = 1; i < xs.length; i++) {
            if (x <= xs[i]) {
                double f = (x - xs[i - 1]) / (xs[i] - xs[i - 1]);
                return ys[i - 1] + f * (ys[i] - ys[i - 1]);
            }
        }
        return ys[ys.length - 1];
    }
}
