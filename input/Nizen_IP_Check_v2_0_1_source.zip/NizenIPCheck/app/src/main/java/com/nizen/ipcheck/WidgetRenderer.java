package com.nizen.ipcheck;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

/** 只负责把缓存结果画到小组件上，不联网。 */
final class WidgetRenderer {
    private WidgetRenderer() {
    }

    static void renderAll(Context context, boolean checking) {
        Context app = context.getApplicationContext();
        AppWidgetManager manager = AppWidgetManager.getInstance(app);
        int[] ids = manager.getAppWidgetIds(new ComponentName(app, IpWidgetProvider.class));
        if (ids == null || ids.length == 0) return;
        manager.updateAppWidget(ids, build(app, checking));
    }

    static RemoteViews build(Context context, boolean checking) {
        SharedPreferences p = Store.prefs(context);
        boolean visible = p.getBoolean(Store.K_VISIBLE, false);
        String ip = p.getString(Store.K_IP, "");
        if (ip == null) ip = "";

        RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.ip_widget);

        String ipText;
        if (!visible) {
            ipText = "*****";
        } else {
            ipText = ip.isEmpty() ? "--" : ip;
        }
        v.setTextViewText(R.id.ip, ipText);
        v.setTextViewText(R.id.country_code, p.getString(Store.K_CC, "--"));
        if (checking) {
            v.setTextViewText(R.id.ip_type, "检测中…");
            v.setTextViewText(R.id.quality, "质量 …");
        } else {
            v.setTextViewText(R.id.ip_type, p.getString(Store.K_TYPE, "未检测"));
            v.setTextViewText(R.id.quality, "质量 " + p.getString(Store.K_QUALITY, "--"));
        }
        v.setTextViewText(R.id.organization, p.getString(Store.K_ORG, "--"));

        v.setContentDescription(R.id.country_code, "点击刷新");
        v.setContentDescription(R.id.ip, visible ? "点击隐藏 IP" : "点击显示 IP");

        v.setOnClickPendingIntent(R.id.country_code,
                actionIntent(context, WidgetActionReceiver.ACTION_REFRESH, 1001));
        v.setOnClickPendingIntent(R.id.ip,
                actionIntent(context, WidgetActionReceiver.ACTION_TOGGLE, 1002));
        return v;
    }

    private static PendingIntent actionIntent(Context context, String action, int requestCode) {
        Intent intent = new Intent(context, WidgetActionReceiver.class);
        intent.setAction(action);
        intent.setPackage(context.getPackageName());
        return PendingIntent.getBroadcast(context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
