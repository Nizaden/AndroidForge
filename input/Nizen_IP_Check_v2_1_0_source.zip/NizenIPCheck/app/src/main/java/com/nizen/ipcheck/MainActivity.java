package com.nizen.ipcheck;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.SharedPreferences;
import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

/** App 页面：重新检测、添加小组件、文字颜色设置、上次检测详情。 */
public class MainActivity extends Activity {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Button recheck;

    private final SharedPreferences.OnSharedPreferenceChangeListener listener =
            (prefs, key) -> {
                if (Store.K_DETAILS.equals(key) || Store.K_UPDATED.equals(key)) showDetails();
            };

    /** 检测在后台线程跑，这里每半秒看一次是否结束，用来恢复按钮 */
    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (IpChecker.isRunning()) {
                handler.postDelayed(this, 500);
            } else {
                updateRecheckButton();
                showDetails();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View root = findViewById(R.id.root);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int l;
            int t;
            int r;
            int b;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets in = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                l = in.left;
                t = in.top;
                r = in.right;
                b = in.bottom;
            } else {
                l = insets.getSystemWindowInsetLeft();
                t = insets.getSystemWindowInsetTop();
                r = insets.getSystemWindowInsetRight();
                b = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(l, t, r, b);
            return insets;
        });

        Button pin = findViewById(R.id.btn_pin);
        pin.setOnClickListener(v -> requestPin());

        recheck = findViewById(R.id.btn_recheck);
        recheck.setOnClickListener(v -> forceRecheck());

        // 文字颜色：手动选择，不跟随系统
        RadioGroup group = findViewById(R.id.text_color_group);
        group.check(Store.isTextWhite(this) ? R.id.text_white : R.id.text_black);
        group.setOnCheckedChangeListener((g, checkedId) -> {
            Store.setTextWhite(this, checkedId == R.id.text_white);
            WidgetRenderer.renderAll(this, IpChecker.isRunning());
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Store.prefs(this).registerOnSharedPreferenceChangeListener(listener);
        showDetails();
        updateRecheckButton();
        if (IpChecker.isRunning()) handler.post(poll);
    }

    @Override
    protected void onPause() {
        Store.prefs(this).unregisterOnSharedPreferenceChangeListener(listener);
        handler.removeCallbacks(poll);
        super.onPause();
    }

    /** 跳过缓存和 5 分钟失败等待，强制重查（被 429 限流的网站仍然不会重试）。 */
    private void forceRecheck() {
        if (IpChecker.isRunning()) {
            Toast.makeText(this, R.string.checking, Toast.LENGTH_SHORT).show();
            return;
        }
        IpChecker.startRefresh(this, null, true);
        updateRecheckButton();
        handler.removeCallbacks(poll);
        handler.postDelayed(poll, 500);
    }

    private void updateRecheckButton() {
        boolean running = IpChecker.isRunning();
        recheck.setEnabled(!running);
        recheck.setText(running ? R.string.checking : R.string.btn_recheck);
    }

    private void showDetails() {
        TextView details = findViewById(R.id.details);
        String text = Store.prefs(this).getString(Store.K_DETAILS, "");
        details.setText(text == null || text.isEmpty() ? getString(R.string.no_details) : text);
    }

    private void requestPin() {
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        ComponentName provider = new ComponentName(this, IpWidgetProvider.class);
        if (manager != null && manager.isRequestPinAppWidgetSupported()) {
            manager.requestPinAppWidget(provider, null, null);
        } else {
            Toast.makeText(this, R.string.pin_unsupported, Toast.LENGTH_LONG).show();
        }
    }
}
