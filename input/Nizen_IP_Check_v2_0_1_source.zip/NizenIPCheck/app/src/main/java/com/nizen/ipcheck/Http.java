package com.nizen.ipcheck;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import javax.net.ssl.HttpsURLConnection;

/** 极简 HTTPS GET：只允许 HTTPS，限制超时和响应大小。 */
final class Http {
    static final String USER_AGENT = "NizenIPCheck/2.0.1 (Android)";
    static final int MAX_JSON_BYTES = 32 * 1024;

    private Http() {
    }

    static String get(String address, int connectTimeoutMs, int readTimeoutMs, int maxBytes) throws IOException {
        if (address == null || !address.startsWith("https://")) {
            throw new IOException("只允许 HTTPS");
        }
        URL url = new URL(address);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        if (!(conn instanceof HttpsURLConnection)) {
            conn.disconnect();
            throw new IOException("不是 HTTPS 连接");
        }
        boolean ok = false;
        try {
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(Math.max(1, connectTimeoutMs));
            conn.setReadTimeout(Math.max(1, readTimeoutMs));
            conn.setUseCaches(false);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("Accept", "application/json, text/plain, */*");
            conn.setRequestProperty("User-Agent", USER_AGENT);
            int code = conn.getResponseCode();
            if (code < 200 || code > 299) {
                throw new IOException("HTTP " + code);
            }
            String body;
            try (InputStream in = conn.getInputStream()) {
                body = readLimited(in, maxBytes);
            }
            ok = true;
            return body;
        } finally {
            // 成功时不 disconnect，让连接回到连接池，线路质量测试可以复用同一条连接
            if (!ok) {
                conn.disconnect();
            }
        }
    }

    static JSONObject getJson(String address, int connectTimeoutMs, int readTimeoutMs) throws IOException {
        String body = get(address, connectTimeoutMs, readTimeoutMs, MAX_JSON_BYTES);
        try {
            return new JSONObject(body);
        } catch (JSONException e) {
            throw new IOException("返回的不是 JSON");
        }
    }

    private static String readLimited(InputStream in, int maxBytes) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(1024);
        byte[] buf = new byte[2048];
        int total = 0;
        int n;
        while ((n = in.read(buf)) != -1) {
            total += n;
            if (total > maxBytes) {
                throw new IOException("响应过大");
            }
            out.write(buf, 0, n);
        }
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }
}
