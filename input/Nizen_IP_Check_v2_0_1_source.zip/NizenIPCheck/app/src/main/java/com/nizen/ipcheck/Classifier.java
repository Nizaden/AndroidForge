package com.nizen.ipcheck;

import java.util.Locale;
import java.util.regex.Pattern;

/**
 * 综合多个数据源判断 IP 类型。
 * 原则：一个来源说了只算“疑似”；两个来源一致，或有权威来源，才下结论；
 * 没查到机房 ≠ 住宅；信息不够一律“未知”。
 */
final class Classifier {

    static final class Signals {
        // Cloudflare
        boolean cfOk;
        String cfWarp = "";
        boolean cfTorLoc;
        // ipquery
        boolean iqOk;
        boolean iqDc;
        boolean iqVpn;
        boolean iqProxy;
        boolean iqTor;
        boolean iqMobile;
        // proxycheck
        boolean pcOk;
        boolean pcProxy;
        boolean pcHasOperator;
        String pcType = "";
        // Tor 官方：null 表示没拿到或 IP 对不上
        Boolean torOfficial;
        // 组织 / ISP / 主机名等英文名称，用于辅助判断
        String names = "";
    }

    static final class Verdict {
        String label;
        String reason;
    }

    private static final String[] CLOUD_WORDS = {
            "amazon", "google cloud", "google llc", "microsoft", "azure", "alibaba", "aliyun",
            "tencent", "huawei cloud", "huaweicloud", "oracle", "digitalocean", "linode", "akamai",
            "vultr", "choopa", "hetzner", "contabo", "leaseweb", "datacamp", "cdn77", "cloudflare",
            "fastly", "upcloud", "scaleway", "ionos", "kamatera", "racknerd", "bandwagon", "peg tech",
            "zenlayer", "gcore", "g-core", "data center", "datacenter", "data centre", "cloud"
    };
    private static final String[] CLOUD_TOKENS = {"aws", "ovh", "idc", "m247", "it7", "dmit", "gcp"};
    private static final String[] HOSTING_WORDS = {"hosting", "colocation", "dedicated", "server"};
    private static final String[] HOSTING_TOKENS = {"vps", "colo", "host"};

    private Classifier() {
    }

    static Verdict classify(Signals s) {
        String t = s.pcType == null ? "" : s.pcType.trim().toLowerCase(Locale.ROOT);
        String names = s.names == null ? "" : s.names.toLowerCase(Locale.ROOT);

        boolean pcTor = s.pcOk && t.equals("tor");
        boolean pcVpnType = s.pcOk && t.equals("vpn");
        // proxycheck 会把普通机房 IP 也标成 VPN；只有带 operator（VPN 运营商）时才算真 VPN
        boolean pcVpn = pcVpnType && s.pcHasOperator;
        boolean pcHosting = s.pcOk && (t.contains("hosting") || t.contains("data")
                || (pcVpnType && !s.pcHasOperator));
        boolean pcRes = s.pcOk && t.equals("residential");
        boolean pcWireless = s.pcOk && (t.equals("wireless") || t.contains("mobile") || t.contains("cellular"));
        boolean pcBusiness = s.pcOk && t.equals("business");
        boolean pcProxyVote = s.pcOk && s.pcProxy && !pcTor && !pcVpnType && !pcHosting;

        boolean cloudKw = containsAny(names, CLOUD_WORDS) || containsToken(names, CLOUD_TOKENS);
        boolean hostKw = containsAny(names, HOSTING_WORDS) || containsToken(names, HOSTING_TOKENS);
        boolean dcKw = cloudKw || hostKw;

        boolean a = s.iqOk && s.iqDc; // ipquery：机房
        boolean b = pcHosting;         // proxycheck：机房/托管

        StringBuilder why = new StringBuilder();
        String base;
        boolean firm = false;

        if ((a && b) || ((a || b) && dcKw)) {
            base = (hostKw && !cloudKw) ? "托管" : "机房";
            firm = true;
            why.append("机房证据：").append(a ? "ipquery " : "").append(b ? "proxycheck " : "")
                    .append(dcKw ? "名称特征" : "").append("；");
        } else if ((a || b) && (pcRes || pcWireless)) {
            base = "";
            why.append("数据源结论冲突（机房 vs 住宅/移动）；");
        } else if (a || b) {
            base = "疑似机房";
            why.append("只有一个来源认为是机房；");
        } else if (pcWireless || (s.iqOk && s.iqMobile)) {
            boolean agree = !dcKw && ((pcWireless && s.iqOk)
                    || (s.iqOk && s.iqMobile && (pcRes || pcWireless)));
            base = agree ? "移动网络" : "疑似移动";
            firm = agree;
            why.append("移动网络证据：").append(pcWireless ? "proxycheck " : "")
                    .append(s.iqOk && s.iqMobile ? "ipquery" : "").append("；");
        } else if (pcRes) {
            if (dcKw) {
                base = "";
                why.append("proxycheck 说住宅，但名称像机房，冲突；");
            } else if (s.iqOk) {
                base = "住宅";
                firm = true;
                why.append("proxycheck 判定住宅，ipquery 未发现机房；");
            } else {
                base = "疑似住宅";
                why.append("只有 proxycheck 判定住宅，缺少第二来源；");
            }
        } else if (pcBusiness && !dcKw) {
            base = s.iqOk ? "商业" : "疑似商业";
            firm = s.iqOk;
            why.append("proxycheck 判定商业网络；");
        } else {
            base = "";
            why.append("基础类型数据不足；");
        }

        // 匿名属性：Tor > VPN > 代理
        int tor;
        if (s.torOfficial != null) {
            tor = s.torOfficial ? 2 : 0; // Tor 官方结果最权威
        } else {
            int v = (s.iqOk && s.iqTor ? 1 : 0) + (pcTor ? 1 : 0) + (s.cfTorLoc ? 1 : 0);
            tor = v >= 2 ? 2 : v;
        }
        boolean warp = "on".equals(s.cfWarp) || "plus".equals(s.cfWarp);
        int vv = (s.iqOk && s.iqVpn ? 1 : 0) + (pcVpn ? 1 : 0);
        int vpn = warp ? 2 : (vv >= 2 ? 2 : vv);
        int pv = (s.iqOk && s.iqProxy ? 1 : 0) + (pcProxyVote ? 1 : 0);
        int proxy = pv >= 2 ? 2 : pv;

        String anon = "";
        if (tor == 2) anon = "Tor";
        else if (vpn == 2) anon = "VPN";
        else if (proxy == 2) anon = "代理";
        else if (tor == 1) anon = "疑似Tor";
        else if (vpn == 1) anon = "疑似VPN";
        else if (proxy == 1) anon = "疑似代理";

        why.append("Tor=").append(level(tor)).append("，VPN=").append(level(vpn))
                .append(warp ? "(WARP)" : "").append("，代理=").append(level(proxy));

        Verdict v = new Verdict();
        if (!anon.isEmpty()) {
            v.label = firm ? base + "·" + anon : anon;
        } else {
            v.label = base.isEmpty() ? "未知" : base;
        }
        v.reason = why.toString();
        return v;
    }

    private static String level(int l) {
        return l == 2 ? "确认" : (l == 1 ? "疑似" : "否");
    }

    private static boolean containsAny(String text, String[] words) {
        for (String w : words) {
            if (text.contains(w)) return true;
        }
        return false;
    }

    private static boolean containsToken(String text, String[] tokens) {
        for (String tok : tokens) {
            Pattern p = Pattern.compile("(^|[^a-z0-9])" + Pattern.quote(tok) + "([^a-z0-9]|$)");
            if (p.matcher(text).find()) return true;
        }
        return false;
    }
}
