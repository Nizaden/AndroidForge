# IP 检测小组件 v2.0.1（Nizen IP Check）

透明背景的 Android 桌面小组件，显示：国家代码、公网 IP（默认隐藏）、IP 类型、线路质量、组织名称。

## 怎么用
- **点左侧国家代码（如 US）**：重新检测。
- **点 \*\*\*\*\***：显示 IP；再点一次隐藏。
- 不会在后台自动刷新。只有第一次添加、还没有任何数据时会自动检测一次。
- 打开 App 可以看到「上次检测详情」：每个数据源的结果、判断依据、本次用了多少流量。

## 数据源（全部 HTTPS，免注册）
| 数据源 | 用途 |
|---|---|
| Cloudflare `/cdn-cgi/trace` | 出口 IP、国家、是否 WARP；线路质量测试目标 |
| api.ipquery.io | 机房 / VPN / 代理 / Tor / 移动网络标志 |
| proxycheck.io v2 | 代理、网络类型（住宅 / 商业 / 机房等），免费版每天约 100 次 |
| ipwho.is | 组织名称（保留英文原文） |
| check.torproject.org | Tor 官方判断（仅在看到的 IP 一致时采用） |

所有数据源都用同一个 IP 查询；返回的 IP 对不上的结果直接丢弃。

## 类型判断规则
- 一个来源说是机房只显示「疑似机房」；两个来源一致，或一个来源加上名称特征（如 Amazon、Vultr），才显示「机房」或「托管」。
- 「住宅」必须由 proxycheck 明确判定为住宅，同时 ipquery 没有发现机房。**没查到机房不会被当成住宅。**
- 各来源说法冲突，或者数据不够时，一律显示「未知」。
- 匿名属性按 Tor ＞ VPN ＞ 代理 的优先级显示，例如「机房·VPN」。只有一个来源支持时加「疑似」。
- proxycheck 会把普通云服务器标成 VPN，所以只有带 VPN 运营商信息时才算真 VPN。

## 线路质量
先发 1 次预热请求，再对 Cloudflare 实际请求 5 次（每次约 300 字节，间隔 200ms），按以下权重打分：
延迟中位数 50%、抖动 20%、成功率 30%。

| 分数 | 等级 |
|---|---|
| ≥85 | 优秀 |
| ≥70 | 良好 |
| ≥55 | 普通 |
| ≥35 | 较差 |
| <35 | 很差 |

有失败时最高只能到「普通」；成功率低于 60% 直接判为「很差」。阈值在 `QualityTester.java` 里，可以自己调。

## 流量与超时
- 单次检测预计 40–70KB，大部分是 HTTPS 握手。实际数值看 App 里的「本次流量」。
- 每个请求的连接和读取超时各 3 秒，整次检测最多约 9 秒；单个响应超过 32KB 直接丢弃。
- 只允许 HTTPS，并且关闭了明文流量。

## 编译
- AGP 8.7.3 / Gradle 8.9 / JDK 17；compileSdk、targetSdk 为 35（Android 15），minSdk 26（Android 8.0）。
- 为什么不是 36：AndroidForge 环境里的 Gradle 是 8.9，只能配 AGP 8.7.x；而 compileSdk 36 需要 AGP 8.9 以上（同时需要 Gradle 8.11.1 以上）。
- 能在 Android 16 手机上正常运行：小组件不受 Android 16 针对 targetSdk 36 的行为变更影响；说明页已经按全面屏（edge-to-edge）处理了系统栏的留白。
- 等 AndroidForge 支持更新的 Gradle 后，把 AGP 升到 8.9 以上，再把 compileSdk/targetSdk 改成 36 即可。
- 纯 Java，不依赖任何第三方库。
- 包名通过 app/build.gradle 里的 `namespace = "com.nizen.ipcheck"` 设置，AndroidManifest.xml 里不写 package。
- release 包使用调试签名，可以直接安装；上架应用商店前请换成自己的签名。
- **本工程没有在作者环境中实际编译过**，如果编译报错，请把日志发回来修改。
