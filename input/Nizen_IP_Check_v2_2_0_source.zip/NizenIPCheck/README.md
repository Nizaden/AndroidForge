# Test（IP 检测小组件）v2.2.0

包名 `com.nizen.ipcheck`。透明背景的 Android 桌面小组件，显示：国家代码、公网 IP（默认隐藏）、IP 类型、IP 质量（干净程度）、组织名称。

## 怎么用
- **点左侧国家代码（如 US）**：刷新。同一 IP 1 天内直接用缓存，不重复查询。
- **点 \*\*\*\*\***：显示 IP；再点一次隐藏。
- **点组织名**：太长时显示省略号，点一下展开（最多 3 行），再点收起。
- **App 里的「重新检测」**：跳过缓存和失败等待，强制重查。
- **App 设置**：小组件文字颜色手动选「黑字 / 白字」（纯黑 / 纯白，无阴影，不跟随系统）。
- 不会在后台自动刷新。只有第一次添加、还没有任何数据时会自动检测一次。
- App 里「上次检测详情」显示每个数据源的结果、判断依据、每一步耗时和本次流量。

## 数据源与查询流程（照搬 FlClash lib/common/ip_quality.dart）
| 批次 | 数据源 | 说明 |
|---|---|---|
| 第 1 批（同时） | `https://4.ident.me/json` | 类型（type）、组织（aso）、国家 |
| 第 1 批 | `http://ip-api.com/json/`（唯一的明文例外） | hosting / mobile / proxy |
| 第 1 批 | `https://api.ipquery.io/` | is_datacenter / is_mobile / VPN / 代理 / Tor + 风险分 |
| 第 2 批 | `https://iplocate.io/api/lookup/{ip}` | is_hosting、公司类型、代理 / VPN / Tor / 滥用 |
| 第 3 批 | `https://api.ipapi.is/?q={ip}` | 机房 / 移动 / 滥用（见下方注意） |
| 第 4 批 | `https://proxycheck.io/v3/{ip}` | 网络类型 + 各种检测标记 |
| 机房评级 | proxycheck v3（不可用时 ipquery） | 只在结果是「机房」时追加，用来看干净程度 |

- 每批间隔 1 秒；上一批全部结束（失败或没给出类型）会立刻问下一批。
- 谁先给出**明确类型**就用谁，并取消其余所有请求。
- ip-api.com / ipquery 只说「不是机房、不是移动」时算**推断住宅**，只有所有来源都没明确类型时才采用。
- 和 FlClash 的不同：FlClash 通过 Clash 内核拿出口 IP；本 App 没有内核，第 1 批直接问「我的 IP」。
  4.ident.me / ip-api.com / api.ipquery.io 都只有 IPv4 解析，所以显示的一定是 IPv4；都拿不到才改问 6.ident.me。
- **注意**：ipapi.is 从 2026-09-01 起，不带 API Key 的请求不再返回机房 / VPN / 滥用等标记，所以它现在基本只会是「没给出类型」。照搬保留，不影响结果。

## 类型（FlClash 原样）
住宅、移动网络、商业、机房；都查不到显示「类型未知」。
- 机房优先（任一机房标记或类型为 hosting）→ 移动网络 → 网站自己声明的类型。
- ident.me / iplocate / ipapi.is 的类型：`isp`→住宅，`business / education / government / banking`→商业，`hosting`→机房。
- proxycheck：`Hosting`→机房，`Wireless`→移动网络，`Residential`→住宅，`Business`→商业。
- 国内运营商宽带在这些数据库里常被标为「商业」，FlClash 也一样，这里没有改。

## 质量（优 / 普通 / 风险）
1. FlClash 原样：Tor 或滥用 → **风险**；住宅 / 移动网络 / 商业 → **优**；机房 → 普通。
2. 我们加的机房评级（机房且没有 Tor / 滥用时）：
| 等级 | 条件 |
|---|---|
| 风险 | Tor、被入侵、爬虫、滥用、攻击记录 ≥10 次；或两个以上网站标了代理/VPN；或风险分高（67–100） |
| 普通 | 只有一个网站标了代理/VPN；或风险分中（34–66） |
| 优 | 没有代理/VPN 标记且风险分低（0–33），干净的机房也可以是优 |
| 普通 | proxycheck 和 ipquery 都拿不到数据时，保持 FlClash 的普通 |

- 风险分优先用 proxycheck，它不可用（每日免费次数用完等）时用 ipquery。
- proxycheck 可信度低于 50 时，它的标记不算；ip-api.com 标代理只作参考，有别的网站也标了才算。
- 阈值都在 `Classifier.java` 开头。

## 缓存与重试
- 同一 IP 结果缓存 1 天（SharedPreferences，App 重启不丢，最多保留 16 个 IP）。
- 整次检测失败后 5 分钟内不自动重试；单个网站失败后 5 分钟内跳过它。
- 遇到 429 限流不重试，按对方给的时间冷却（ip-api.com 用 `X-Ttl`，其余用 `Retry-After`，没有就 10 分钟）；「重新检测」也不会绕过限流冷却。
- 每个请求连接 / 读取超时各 4 秒（FlClash 单个请求 8 秒），查询最多 12 秒，机房评级再最多 6 秒；单个响应超过 32KB 丢弃；不跟随跳转。

## 网络安全
`res/xml/network_security_config.xml`：默认禁止明文；只对 `ip-api.com`（不含子域名）允许 HTTP。代码里也做了同样限制。

## 编译
- AGP 8.7.3 / Gradle 8.9 / JDK 17；compileSdk、targetSdk 35（Android 15），minSdk 26（Android 8.0）。
- 为什么不是 36：AndroidForge 环境的 Gradle 是 8.9，只能配 AGP 8.7.x；compileSdk 36 需要 AGP 8.9+（同时 Gradle 8.11.1+）。
- 包名通过 app/build.gradle 里的 `namespace = "com.nizen.ipcheck"` 设置，AndroidManifest.xml 里不写 package。
- 纯 Java，不依赖任何第三方库。
- 图标：自适应图标（`mipmap-anydpi-v26`），蓝底白字花体「IP」，支持 Android 13+ 主题图标。字形取自 STIX 字体（SIL OFL 1.1），已转为矢量路径。
- release 包使用调试签名，可以直接安装；上架前请换成自己的签名。
- **本工程没有在作者环境中实际编译过**，如果编译报错，请把日志发回来修改。

## 授权
查询流程、各来源解析和类型/质量规则翻译自 FlClash（https://github.com/chen08209/FlClash ，GPL-3.0）。自己使用没有限制；如果把 APK 分发给别人，需要同样以 GPL-3.0 开源并注明出处。

## 版本记录
- 2.2.0：查询流程和类型/质量规则改为照搬 FlClash（新增 iplocate.io、ipapi.is，去掉 ipwho.is）；质量改为 优 / 普通 / 风险，机房额外用 proxycheck 评干净程度；缓存、重试规则保持不变；界面不变。
- 2.1.0：改为分批数据源（ident.me / ip-api.com / ipquery / proxycheck v3 / ipwho.is）；质量改为只看干净程度；1 天缓存、失败 5 分钟不重试、429 不重试；App 内「重新检测」；手动黑字/白字、去阴影；组织名点按展开；应用名改为 Test，新图标。
- 2.0.1：上一版。
