package com.nizen.ipcheck;

import android.content.Context;
import android.content.SharedPreferences;

/** 本地缓存：小组件只显示这里保存的结果，不会自己联网。 */
final class Store {
    static final String PREFS = "ip_widget_state";

    static final String K_IP = "ip";
    static final String K_CC = "country_code";
    static final String K_TYPE = "ip_type";
    static final String K_QUALITY = "quality";
    static final String K_ORG = "organization";
    static final String K_VISIBLE = "ip_visible";
    static final String K_UPDATED = "updated_at";
    static final String K_DETAILS = "details";

    private Store() {
    }

    static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean hasData(Context context) {
        return prefs(context).getLong(K_UPDATED, 0L) > 0L;
    }

    static void save(Context context, IpChecker.DetectionResult r) {
        prefs(context).edit()
                .putString(K_IP, r.ip == null ? "" : r.ip)
                .putString(K_CC, r.countryCode == null ? "--" : r.countryCode)
                .putString(K_TYPE, r.typeLabel == null ? "未知" : r.typeLabel)
                .putString(K_QUALITY, r.qualityLabel == null ? "--" : r.qualityLabel)
                .putString(K_ORG, r.organization == null ? "--" : r.organization)
                .putString(K_DETAILS, r.details == null ? "" : r.details)
                .putLong(K_UPDATED, System.currentTimeMillis())
                .commit(); // 在后台线程执行，立即写盘
    }

    static void toggleIpVisible(Context context) {
        SharedPreferences p = prefs(context);
        p.edit().putBoolean(K_VISIBLE, !p.getBoolean(K_VISIBLE, false)).apply();
    }

    static void hideIp(Context context) {
        prefs(context).edit().putBoolean(K_VISIBLE, false).apply();
    }
}
