package com.nizen.ipcheck;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 本地保存（SharedPreferences，App 重启不丢）：
 * - 小组件当前显示的结果
 * - 按 IP 的检测结果缓存（1 天）
 * - 整次检测失败时间（5 分钟内不自动重试）
 * - 各数据源的冷却：普通失败 5 分钟；429/配额用完按限流冷却（强制重查也不重试）
 */
final class Store {
    static final String PREFS = "ip_widget_state";

    static final String K_IP = "ip";
    static final String K_CC = "country_code";
    static final String K_TYPE = "ip_type";
    static final String K_QUALITY = "quality";
    static final String K_ORG = "organization";
    static final String K_VISIBLE = "ip_visible";
    static final String K_UPDATED = "updated_at";
    static final String K_DETAILS = "details";
    static final String K_CACHE = "result_cache";
    static final String K_FAIL_AT = "fail_at";
    static final String K_TEXT_WHITE = "text_white";
    static final String K_ORG_EXPANDED = "org_expanded";

    static final long CACHE_TTL_MS = 24L * 60 * 60 * 1000;
    static final long FAIL_BACKOFF_MS = 5L * 60 * 1000;
    private static final int CACHE_MAX = 16;

    private Store() {
    }

    static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean hasData(Context context) {
        return prefs(context).getLong(K_UPDATED, 0L) > 0L;
    }

    // ---------------- 当前显示 ----------------
    static synchronized void save(Context context, IpChecker.DetectionResult r) {
        SharedPreferences p = prefs(context);
        long now = System.currentTimeMillis();
        SharedPreferences.Editor e = p.edit()
                .putString(K_IP, r.ip == null ? "" : r.ip)
                .putString(K_CC, r.countryCode == null ? "--" : r.countryCode)
                .putString(K_TYPE, r.typeLabel == null ? "未知" : r.typeLabel)
                .putString(K_QUALITY, r.qualityLabel == null ? "未知" : r.qualityLabel)
                .putString(K_ORG, r.organization == null ? "--" : r.organization)
                .putString(K_DETAILS, r.details == null ? "" : r.details)
                .putLong(K_UPDATED, now);
        if (r.failed) {
            e.putLong(K_FAIL_AT, now);
        } else {
            e.remove(K_FAIL_AT);
        }
        if (r.cacheable && !r.fromCache && r.ip != null && !r.ip.isEmpty()) {
            e.putString(K_CACHE, putCache(p.getString(K_CACHE, null), r, now));
        }
        e.commit(); // 在后台线程执行，立即写盘
    }

    /** 上次整次检测失败后 5 分钟内，返回剩余毫秒；否则 0。 */
    static long failureBackoffLeft(Context context) {
        long at = prefs(context).getLong(K_FAIL_AT, 0L);
        long left = at + FAIL_BACKOFF_MS - System.currentTimeMillis();
        return at > 0 && left > 0 ? left : 0;
    }

    static void toggleIpVisible(Context context) {
        SharedPreferences p = prefs(context);
        p.edit().putBoolean(K_VISIBLE, !p.getBoolean(K_VISIBLE, false)).apply();
    }

    static void hideIp(Context context) {
        prefs(context).edit().putBoolean(K_VISIBLE, false).apply();
    }

    /** 文字颜色：只在 App 设置里手动切换，默认黑字。 */
    static boolean isTextWhite(Context context) {
        return prefs(context).getBoolean(K_TEXT_WHITE, false);
    }

    static void setTextWhite(Context context, boolean white) {
        prefs(context).edit().putBoolean(K_TEXT_WHITE, white).commit();
    }

    static void toggleOrgExpanded(Context context) {
        SharedPreferences p = prefs(context);
        p.edit().putBoolean(K_ORG_EXPANDED, !p.getBoolean(K_ORG_EXPANDED, false)).commit();
    }

    // ---------------- 按 IP 缓存（1 天） ----------------
    static synchronized IpChecker.DetectionResult cached(Context context, String ip) {
        String raw = prefs(context).getString(K_CACHE, null);
        if (raw == null || ip == null) return null;
        try {
            JSONObject all = new JSONObject(raw);
            JSONObject o = all.optJSONObject(ip);
            if (o == null) return null;
            long t = o.optLong("t", 0L);
            long age = System.currentTimeMillis() - t;
            if (t <= 0 || age < 0 || age > CACHE_TTL_MS) return null;
            IpChecker.DetectionResult r = new IpChecker.DetectionResult();
            r.ip = ip;
            r.countryCode = o.optString("cc", "--");
            r.typeLabel = o.optString("type", "未知");
            r.qualityLabel = o.optString("quality", "未知");
            r.organization = o.optString("org", "--");
            r.details = o.optString("details", "");
            r.cacheable = true;
            r.fromCache = true;
            r.cacheAgeMs = age;
            return r;
        } catch (JSONException e) {
            return null;
        }
    }

    private static String putCache(String raw, IpChecker.DetectionResult r, long now) {
        JSONObject all;
        try {
            all = raw == null ? new JSONObject() : new JSONObject(raw);
        } catch (JSONException e) {
            all = new JSONObject();
        }
        try {
            // 清掉过期的，超过上限时删最旧的
            List<String> keys = new ArrayList<>();
            Iterator<String> it = all.keys();
            while (it.hasNext()) keys.add(it.next());
            String oldest = null;
            long oldestT = Long.MAX_VALUE;
            for (String k : keys) {
                JSONObject o = all.optJSONObject(k);
                long t = o == null ? 0L : o.optLong("t", 0L);
                if (o == null || now - t > CACHE_TTL_MS || now < t) {
                    all.remove(k);
                } else if (t < oldestT) {
                    oldestT = t;
                    oldest = k;
                }
            }
            if (all.length() >= CACHE_MAX && oldest != null && !all.has(r.ip)) {
                all.remove(oldest);
            }
            JSONObject o = new JSONObject();
            o.put("t", now);
            o.put("cc", r.countryCode);
            o.put("type", r.typeLabel);
            o.put("quality", r.qualityLabel);
            o.put("org", r.organization);
            o.put("details", r.details);
            all.put(r.ip, o);
        } catch (JSONException ignored) {
            // 写缓存失败不影响显示
        }
        return all.toString();
    }

    // ---------------- 数据源冷却 ----------------
    static synchronized void coolDown(Context context, Sources.Id id, long durationMs, boolean rateLimited, String why) {
        prefs(context).edit()
                .putLong("cd_until_" + id.name(), System.currentTimeMillis() + Math.max(0, durationMs))
                .putBoolean("cd_rl_" + id.name(), rateLimited)
                .putString("cd_msg_" + id.name(), why == null ? "" : why)
                .apply();
    }

    static synchronized void clearCoolDown(Context context, Sources.Id id) {
        SharedPreferences p = prefs(context);
        if (p.contains("cd_until_" + id.name())) {
            p.edit().remove("cd_until_" + id.name()).remove("cd_rl_" + id.name())
                    .remove("cd_msg_" + id.name()).apply();
        }
    }

    /**
     * 现在是否要跳过这个数据源；返回跳过原因，null 表示可以请求。
     * 限流冷却任何时候都跳过；普通失败冷却在强制重查时忽略。
     */
    static synchronized String skipReason(Context context, Sources.Id id, boolean force) {
        SharedPreferences p = prefs(context);
        long left = p.getLong("cd_until_" + id.name(), 0L) - System.currentTimeMillis();
        if (left <= 0) return null;
        boolean rl = p.getBoolean("cd_rl_" + id.name(), false);
        if (!rl && force) return null;
        long sec = (left + 999) / 1000;
        String msg = p.getString("cd_msg_" + id.name(), "");
        return (rl ? "限流冷却中" : "上次失败，5 分钟内不重试") + "（还剩 " + sec + " 秒）"
                + (msg == null || msg.isEmpty() ? "" : "：" + msg);
    }
}
