package com.nizen.ipcheck;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

import javax.net.ssl.HttpsURLConnection;

/**
 * 极简 GET。除 ip-api.com 外只允许 HTTPS（ip-api.com 免费版没有 HTTPS，
 * network_security_config.xml 里也只对这一个域名放开明文）。
 * Call.cancel() 会立即断开连接，用于“先到先用，取消其余请求”。
 */
final class Http {
    static final String USER_AGENT = "NizenIPCheck/2.2.0 (Android)";
    static final int MAX_BYTES = 32 * 1024;
    /** 唯一允许明文 HTTP 的域名 */
    static final String CLEARTEXT_HOST = "ip-api.com";

    private Http() {
    }

    static final class Response {
        int code;
        String body = "";
        String xRl;        // ip-api.com：本窗口剩余次数
        String xTtl;       // ip-api.com：限流窗口剩余秒数
        String retryAfter; // 通用 429 头
    }

    /** 429 / 配额用完：本次不重试，并进入冷却。 */
    static final class RateLimitedException extends IOException {
        final long coolDownMs;

        RateLimitedException(String msg, long coolDownMs) {
            super(msg);
            this.coolDownMs = coolDownMs;
        }
    }

    /** 可取消的一次请求。 */
    static final class Call {
        private volatile HttpURLConnection conn;
        private volatile boolean cancelled;

        void cancel() {
            cancelled = true;
            HttpURLConnection c = conn;
            if (c != null) {
                try {
                    c.disconnect();
                } catch (Throwable ignored) {
                    // 已断开
                }
            }
        }

        boolean isCancelled() {
            return cancelled;
        }
    }

    static Response get(String address, int connectTimeoutMs, int readTimeoutMs, Call call) throws IOException {
        if (address == null) throw new IOException("地址为空");
        URL url = new URL(address);
        String protocol = url.getProtocol().toLowerCase(Locale.ROOT);
        String host = url.getHost().toLowerCase(Locale.ROOT);
        boolean https = "https".equals(protocol);
        if (!https && !("http".equals(protocol) && CLEARTEXT_HOST.equals(host))) {
            throw new IOException("只允许 HTTPS");
        }
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        if (https && !(conn instanceof HttpsURLConnection)) {
            conn.disconnect();
            throw new IOException("不是 HTTPS 连接");
        }
        if (call != null) {
            call.conn = conn;
            if (call.isCancelled()) {
                conn.disconnect();
                throw new IOException("已取消");
            }
        }
        try {
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(Math.max(1, connectTimeoutMs));
            conn.setReadTimeout(Math.max(1, readTimeoutMs));
            conn.setUseCaches(false);
            // 不跟随跳转，避免被引到其他域名或明文地址
            conn.setInstanceFollowRedirects(false);
            conn.setRequestProperty("Accept", "application/json, */*");
            conn.setRequestProperty("User-Agent", USER_AGENT);
            Response r = new Response();
            r.code = conn.getResponseCode();
            r.xRl = conn.getHeaderField("X-Rl");
            r.xTtl = conn.getHeaderField("X-Ttl");
            r.retryAfter = conn.getHeaderField("Retry-After");
            InputStream in = r.code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            if (in != null) {
                try (InputStream s = in) {
                    r.body = readLimited(s, MAX_BYTES);
                }
            }
            return r;
        } catch (IOException e) {
            if (call != null && call.isCancelled()) throw new IOException("已取消");
            throw e;
        } finally {
            conn.disconnect();
        }
    }

    /** 解析“秒数”头，失败返回 -1。 */
    static long seconds(String header) {
        if (header == null) return -1;
        try {
            return Long.parseLong(header.trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static String readLimited(InputStream in, int maxBytes) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(2048);
        byte[] buf = new byte[2048];
        int total = 0;
        int n;
        while ((n = in.read(buf)) != -1) {
            total += n;
            if (total > maxBytes) throw new IOException("响应过大");
            out.write(buf, 0, n);
        }
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }
}
