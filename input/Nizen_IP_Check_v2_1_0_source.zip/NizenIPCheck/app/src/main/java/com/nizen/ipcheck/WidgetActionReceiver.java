package com.nizen.ipcheck;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** 处理小组件点击。未导出，只有本 App 的 PendingIntent 能触发。 */
public class WidgetActionReceiver extends BroadcastReceiver {
    static final String ACTION_REFRESH = "com.nizen.ipcheck.action.REFRESH";
    static final String ACTION_TOGGLE = "com.nizen.ipcheck.action.TOGGLE_IP";
    static final String ACTION_TOGGLE_ORG = "com.nizen.ipcheck.action.TOGGLE_ORG";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_TOGGLE.equals(action)) {
            Store.toggleIpVisible(context);
            WidgetRenderer.renderAll(context, IpChecker.isRunning());
        } else if (ACTION_TOGGLE_ORG.equals(action)) {
            Store.toggleOrgExpanded(context);
            WidgetRenderer.renderAll(context, IpChecker.isRunning());
        } else if (ACTION_REFRESH.equals(action)) {
            // 小组件上的刷新走缓存（同一 IP 1 天内不重查）；强制重查在 App 里
            IpChecker.startRefresh(context, goAsync(), false);
        }
    }
}
