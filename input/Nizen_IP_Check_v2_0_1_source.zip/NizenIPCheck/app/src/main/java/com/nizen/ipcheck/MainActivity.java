package com.nizen.ipcheck;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.SharedPreferences;
import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/** 说明页：添加小组件 + 查看上次检测详情（含本次流量）。 */
public class MainActivity extends Activity {

    private final SharedPreferences.OnSharedPreferenceChangeListener listener =
            (prefs, key) -> showDetails();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View root = findViewById(R.id.root);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int l;
            int t;
            int r;
            int b;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets in = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                l = in.left;
                t = in.top;
                r = in.right;
                b = in.bottom;
            } else {
                l = insets.getSystemWindowInsetLeft();
                t = insets.getSystemWindowInsetTop();
                r = insets.getSystemWindowInsetRight();
                b = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(l, t, r, b);
            return insets;
        });

        Button pin = findViewById(R.id.btn_pin);
        pin.setOnClickListener(v -> requestPin());
    }

    @Override
    protected void onResume() {
        super.onResume();
        Store.prefs(this).registerOnSharedPreferenceChangeListener(listener);
        showDetails();
    }

    @Override
    protected void onPause() {
        Store.prefs(this).unregisterOnSharedPreferenceChangeListener(listener);
        super.onPause();
    }

    private void showDetails() {
        TextView details = findViewById(R.id.details);
        String text = Store.prefs(this).getString(Store.K_DETAILS, "");
        details.setText(text == null || text.isEmpty() ? getString(R.string.no_details) : text);
    }

    private void requestPin() {
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        ComponentName provider = new ComponentName(this, IpWidgetProvider.class);
        if (manager != null && manager.isRequestPinAppWidgetSupported()) {
            manager.requestPinAppWidget(provider, null, null);
        } else {
            Toast.makeText(this, R.string.pin_unsupported, Toast.LENGTH_LONG).show();
        }
    }
}
